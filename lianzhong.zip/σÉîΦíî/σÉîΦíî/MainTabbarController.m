//
//  MainTabbarController.m
//  同行
//
//  Created by Duke on 2017/3/1.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "MainTabbarController.h"

//@interface MainTabbarController ()
//
//@property (strong, nonatomic) MainViewController *mainVC;
//@property (strong, nonatomic) DiscoverViewController *discoverVC;
//@property (strong, nonatomic) OrderViewController *orderVC;
//@property (strong, nonatomic) UserViewController *userVC;
//
//@end

@implementation MainTabbarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 设置为不透明
    [[UITabBar appearance] setTranslucent:NO];
    // 设置背景颜色
    [UITabBar appearance].barTintColor = [UIColor whiteColor];
    [UITabBar appearance].tintColor = [UIColor colorWithRed:0.62f green:0.62f blue:0.63f alpha:1.00f];
    
    // 拿到整个导航控制器的外观
    UITabBarItem * item = [UITabBarItem appearance];
    item.titlePositionAdjustment = UIOffsetMake(0, 1.5);
    
    // 普通状态
    NSMutableDictionary * normalAtts = [NSMutableDictionary dictionary];
    normalAtts[NSFontAttributeName] = [UIFont systemFontOfSize:10];
    normalAtts[NSForegroundColorAttributeName] = [UIColor colorWithRed:0.62f green:0.62f blue:0.63f alpha:1.00f];
    [item setTitleTextAttributes:normalAtts forState:UIControlStateNormal];
    
    // 选中状态
    NSMutableDictionary *selectAtts = [NSMutableDictionary dictionary];
    selectAtts[NSFontAttributeName] = [UIFont systemFontOfSize:10];
    selectAtts[NSForegroundColorAttributeName] = [UIColor colorWithRed:160/255.0 green:219/255.0 blue:1.0 alpha:1.00f];
    [item setTitleTextAttributes:selectAtts forState:UIControlStateSelected];
    
}


@end
