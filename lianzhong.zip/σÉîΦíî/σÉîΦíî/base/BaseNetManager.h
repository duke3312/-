//
//  BaseNetManager.h
//  MET
//
//  Created by Maxfire on 2016/10/24.
//  Copyright © 2016年 Maxfire. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseNetManager : NSObject

/**
 *  单例
 */
+ (BaseNetManager *)sharedManager;

/**
 * POST请求
 *
 * @param parameters 参数
 */
- (NSDictionary *)sendDataToServer:(id)parameters;

- (NSDictionary *)readDataWithData:(NSData *)data;

/**
 * 登录
 *
 * @param parameters 参数
 */
//- (NSDictionary *)sendParametersToServer:(id)parameters;

//- (void)outLine;//退出登录
//- (BOOL)isLogin;//判断是否登录！
//- (BOOL)autoLogin;//自动登录
//- (void)stopHeart; //结束心跳
//- (void)loginWithAccount:(NSString *)phoneNumber AndPassword:(NSString *)password;

@end









