//
//  BaseRequest.h
//  同行
//
//  Created by Duke on 2017/3/2.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol BaseRequestReponseDelegate <NSObject>
@required
/** 如果不用block返回数据的话，这个方法必须实现*/
- (void)requestSuccessReponse:(BOOL)success response:(id)response message:(NSString *)message;
@end

typedef void(^APIDicCompletion)(id response, BOOL success, NSString *message);
@interface BaseRequest : NSObject

@property (nonatomic, weak) id <BaseRequestReponseDelegate> tx_delegate;
/** 链接*/
@property (nonatomic, copy) NSString *tx_url;
/** 默认GET*/
@property (nonatomic, assign) BOOL tx_isPost;
/** 图片数组*/
@property (nonatomic, strong) NSArray <UIImage *>*tx_imageArray;

/** 构造方法*/
+ (instancetype)tx_request;
+ (instancetype)tx_requestWithUrl:(NSString *)tx_url;
+ (instancetype)tx_requestWithUrl:(NSString *)tx_url isPost:(BOOL)tx_isPost;
+ (instancetype)tx_requestWithUrl:(NSString *)tx_url isPost:(BOOL)tx_isPost delegate:(id <BaseRequestReponseDelegate>)tx_delegate;

/** 开始请求，如果设置了代理，不需要block回调*/
- (void)tx_sendRequest;
/** 开始请求，没有设置代理，或者设置了代理，需要block回调，block回调优先级高于代理*/
- (void)tx_sendRequestWithCompletion:(APIDicCompletion)completion;
