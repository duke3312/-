//
//  BaseRequest.m
//  同行
//
//  Created by Duke on 2017/3/2.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "BaseRequest.h"
#import "RequestManager.h"
#import "MJExtension.h"
#import "NSString+Addition.h"
#import "NSDictionary+Addition.h"
#import "AFNetworkReachabilityManager.h"
#import "NSNotificationCenter+Addition.h"

@implementation BaseRequest

#pragma mark - 构造
+ (instancetype)tx_request {
    return [[self alloc] init];
}

+ (instancetype)tx_requestWithUrl:(NSString *)tx_url {
    return [self tx_requestWithUrl:tx_url isPost:NO];
}

+ (instancetype)tx_requestWithUrl:(NSString *)tx_url isPost:(BOOL)tx_isPost {
    return [self tx_requestWithUrl:tx_url isPost:tx_isPost delegate:nil];
}

+ (instancetype)tx_requestWithUrl:(NSString *)tx_url isPost:(BOOL)tx_isPost delegate:(id <BaseRequestReponseDelegate>)tx_delegate {
    BaseRequest *request = [self tx_request];
    request.tx_url = tx_url;
    request.tx_isPost = tx_isPost;
    request.tx_delegate = tx_delegate;
    return request;
}

#pragma mark - 发送请求
- (void)tx_sendRequest {
    [self tx_sendRequestWithCompletion:nil];
}

- (void)tx_sendRequestWithCompletion:(APIDicCompletion)completion {
    
    // 链接
    NSString *urlStr = self.tx_url;
    if (urlStr.length == 0) return ;
    
    // 参数
    NSDictionary *params = [self params];
    
    // 普通POST请求
    if (self.tx_isPost) {
        if (self.tx_imageArray.count == 0) {
            // 开始请求
            [RequestManager POST:[urlStr noWhiteSpaceString] parameters:params responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
                
                // 处理数据
                [self handleResponse:responseObject completion:completion];
            } failure:^(NSError *error) {
                // 数据请求失败，暂时不做处理
            }];
        }
        
    } else { // 普通GET请求
        // 开始请求
        [RequestManager GET:[urlStr noWhiteSpaceString] parameters:params responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
            
            // 处理数据
            [self handleResponse:responseObject completion:completion];
        } failure:^(NSError *error) {
            // 数据请求失败，暂时不做处理
        }];
    }
    
    // 上传图片
    if (self.tx_imageArray.count) {
        [RequestManager POST:[urlStr noWhiteSpaceString] parameters:params responseSeializerType:ResponseSeializerTypeJSON constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            NSInteger imgCount = 0;
            for (UIImage *image in self.tx_imageArray) {
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss:SSS";
                NSString *fileName = [NSString stringWithFormat:@"%@%@.png",[formatter stringFromDate:[NSDate date]],@(imgCount)];
                //                [NSString stringWithFormat:@"uploadFile%@",@(imgCount)]
                [formData appendPartWithFileData:UIImagePNGRepresentation(image) name:@"file" fileName:fileName mimeType:@"image/png"];
                imgCount++;
            }
        } success:^(id responseObject) {
            // 处理数据
            [self handleResponse:responseObject completion:completion];
        } failure:^(NSError *error) {
            // 数据请求失败，暂时不做处理
        }];
    }
}

- (void)handleResponse:(id)responseObject completion:(APIDicCompletion)completion {
    // 接口约定，如果message为retry即重试
    if ([responseObject[@"message"] isEqualToString:@"retry"]) {
        [self tx_sendRequestWithCompletion:completion];
        return  ;
    }
    
    // 数据请求成功回调
    BOOL success = [responseObject[@"message"] isEqualToString:@"success"];
    if (completion) {
        completion(responseObject[@"data"], success, @"");
    } else if (self.tx_delegate) {
        if ([self.tx_delegate respondsToSelector:@selector(requestSuccessReponse:response:message:)]) {
            [self.tx_delegate requestSuccessReponse:success response:responseObject[@"data"] message:@""];
        }
    }
    // 请求成功，发布通知
//    [NSNotificationCenter postNotification:kRequestSuccessNotification];
}

// 设置链接
- (void)settx_url:(NSString *)tx_url {
    if (tx_url.length == 0 || [tx_url isKindOfClass:[NSNull class]]) {
        return ;
    }
    _tx_url = tx_url;
}

- (NSDictionary *)params {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    
    /**
     GET /neihan/stream/mix/v1/?content_type=-101 & ac=WIFI & aid=7 & app_name=joke_essay & channel=App%20Store & count=50 & device_id=10752255605 & device_platform=iphone & device_type=iPhone%206%20Plus & idfa=832E262C-31D7-488A-8856-69600FAABE36 & iid=5316804410 & live_sdk_version=120&max_time=1488433788.41 & openudid=cbb1d9e8770b26c39fac806b79bf263a50da6666 & os_api=18 & os_version=9.3.4 & screen_width=1242 & tag=joke & version_code=5.5.0 & vid=4A4CBB9E-ADC3-426B-B562-9FC8173FDA52 HTTP/1.1
     
     http://lz.lzhealth.com.cn/api/ads/?positions=top%2Cmiddle%2Cbottom
     
     _ga=GA1.2.732729183.1467731127; install_id=5316804410; login_flag=319157cead347271ef233ba429923e3b; qh[360]=1; sessionid=b391787a2cd16be0f914259f0cf829a4; sid_guard="b391787a2cd16be0f914259f0cf829a4|1473218826|2591916|Fri, 07-Oct-2016 03:25:42 GMT"; sid_tt=b391787a2cd16be0f914259f0cf829a4; uuid="w:9ce15113cb34468795d7aff3edddd670
     */
    
    params[@"tag"] = @"joke";
    params[@"iid"] = @"5316804410";
    params[@"os_version"] = @"9.3.4";
    params[@"os_api"] = @"18";
    
    params[@"app_name"] = @"joke_essay";
    params[@"channel"] = @"App Store";
    params[@"device_platform"] = @"iphone";
    params[@"idfa"] = @"832E262C-31D7-488A-8856-69600FAABE36";
    params[@"live_sdk_version"] = @"120";
    
    params[@"vid"] = @"4A4CBB9E-ADC3-426B-B562-9FC8173FDA52";
    params[@"openudid"] = @"cbb1d9e8770b26c39fac806b79bf263a50da6666";
    params[@"device_type"] = @"iPhone 6 Plus";
    params[@"version_code"] = @"5.5.0";
    params[@"ac"] = @"WIFI";
    params[@"screen_width"] = @"1242";
    params[@"device_id"] = @"10752255605";
    params[@"aid"] = @"7";
    params[@"count"] = @"50";
    params[@"max_time"] = [NSString stringWithFormat:@"%.2f", [[NSDate date] timeIntervalSince1970]];
    
    [params addEntriesFromDictionary:self.mj_keyValues];
    
    if ([params.allKeys containsObject:@"tx_delegate"]) {
        [params removeObjectForKey:@"tx_delegate"];
    }
    if ([params.allKeys containsObject:@"tx_isPost"]) {
        [params removeObjectForKey:@"tx_isPost"];
    }
    if ([params.allKeys containsObject:@"tx_url"]) {
        [params removeObjectForKey:@"tx_url"];
    }
    if (self.tx_imageArray.count == 0) {
        if ([params.allKeys containsObject:@"tx_imageArray"]) {
            [params removeObjectForKey:@"tx_imageArray"];
        }
    }
    return params;
}

@end
