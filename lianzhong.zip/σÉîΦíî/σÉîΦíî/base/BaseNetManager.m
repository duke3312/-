//
//  BaseNetManager.m
//  MET
//
//  Created by Maxfire on 2016/10/24.
//  Copyright © 2016年 Maxfire. All rights reserved.
//

#import "BaseNetManager.h"
#import "ParseData.h"
#import "ErrorInfo.h"
#import "LoginWithRC.h"
#import "MBProgressHUD+PY.h"
#import "LoginViewController.h"

@implementation BaseNetManager

/**
 *  单例
 */
+ (BaseNetManager *)sharedManager{
    
    // 保证线程安全，defaultSocket只执行一次
    static BaseNetManager *_manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _manager = [[BaseNetManager alloc] init];
    });
    return _manager;
}

/**
 * 登录
 * parameters  要发送的参数
 */
- (NSDictionary *)sendParametersToServer:(id)parameters{
    //第一步，创建url
    NSURL *url = [NSURL URLWithString:domainStr] ;
    //第二步，创建请求
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:parameters];
    //第三步，连接服务器
    NSData *received = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    if (received) {
        
    }
    NSDictionary *respObj = [NSJSONSerialization JSONObjectWithData:received options:kNilOptions error:nil];
    
    return respObj;
}

/**
 * 向服务器发送请求
 * parameters  要发送的参数
 */
- (NSDictionary *)sendDataToServer:(id)parameters{
    
    //    NSData *data = [[NSData alloc] initWithData:parameters];
//    NSLog(@"token = %@",self.token);
    NSMutableData *sendData = [NSMutableData data];
    [sendData appendData:parameters];
    
    //字节流长度
    long length = 0;
    Byte *testByte = (Byte *)[sendData bytes];
    for(int i=0; i<[sendData length]; i++){
        length += testByte[i];
    }
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:httpUrl]];
    [request setHTTPMethod:@"POST"];
    [request setValue:[BaseNetManager headerWithLength:length] forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:sendData];
    [request setTimeoutInterval:10]; //请求超时
    //接受返回数据
    NSData *received = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSDictionary *dataDic = [self readDataWithData:received];
    return dataDic;
}

+ (NSString *)headerWithLength:(long)length{
    return [NSString stringWithFormat:@"application/octet-stream; Charset=UTF-8, Connection=Keep-Alive,Content-length=%ld",length];
}

- (NSDictionary *)readDataWithData:(NSData *)data {
    

}

//
//#pragma mark --- 从本地读取token数据
//-(void)readNSUserDefaults{
//    NSUserDefaults *userDefaultes = [NSUserDefaults standardUserDefaults];
//    if (self.token == nil) {
//        self.token = [userDefaultes stringForKey:@"token"];
//    }
//}
//
//- (void)loginWithAccount:(NSString *)phoneNumber AndPassword:(NSString *)password{
//    
//    [self readNSUserDefaults];
//    if (self.token != nil) {
//        //登录
//        NSMutableData *sendData = [NSMutableData data];
//        //        [sendData appendStringToData:self.token];
//        [sendData appendShortToData:1002];
//        [sendData appendByteToData:1];
//        //IP:  @"http://192.168.120.95:8091"  [NSString stringWithFormat:@"http://%@:8091",socketIp]
//        NSDictionary *receivedDic = [[BaseNetManager sharedManager] sendDataToServer:sendData];
//        //        ParseData *parse = [[ParseData alloc]init];
//        //        parse.tempData = received;
//        //        NSMutableDictionary *dataDic = [NSMutableDictionary dictionary];
//        //        short cmd = [parse parseDataToShort];
//        //        short type = [parse parseDataToByte];
//        //        if (cmd == 1) {
//        //            short errCode = [parse parseDataToShort];
//        //            NSString *errDetail = [parse parseDataToString];
//        //            [dataDic setObject:@(errCode) forKey:@"errCode"];
//        //            if (errDetail) {
//        //                [dataDic setObject:errDetail forKey:@"errDetail"];
//        //            }
//        //
//        //            [ErrorInfo getErrorInfo:dataDic];
//        //            NSLog(@"erroCode=%d",errCode);
//        //        }
//        
//        //        [dataDic setObject:@(cmd) forKey:@"cmd"];
//        //        [dataDic setObject:@(type) forKey:@"type"];
//        //        NSLog(@"cmd=%d \n type = %d",cmd, type);
//        //        if (cmd == 1002 && type == 1) {
//        //            NSLog(@"自动登录成功");
//        //            UserModel *user = [[UserModel alloc]init];
//        //            user.ID = [parse parseDataToLong];
//        //            user.name = [parse parseDataToString];
//        //            user.headUrl = [parse parseDataToString];
//        //            user.imToken = [parse parseDataToString];
//        //            user.vipLevelNum = [parse parseDataToInt];
//        //            user.currentGoldNum = [parse parseDataToInt];
//        //            user.curentTicketNum = [parse parseDataToInt];
//        //            user.currentFansNum = [parse parseDataToInt];
//        //            user.isBindWX = [parse parseDataToBool];
//        //            user.currentPushMsgNum = [parse parseDataToInt];
//        //
//        //            user.sex = [parse parseDataToByte];
//        //            user.birthday = [parse parseDataToString];
//        //            user.realName = [parse parseDataToString];
//        //            user.sign = [parse parseDataToString];
//        //            user.identityID = [parse parseDataToString];
//        //            user.address = [parse parseDataToString];
//        //            user.account = [parse parseDataToString];
//        //            user.record = [parse parseDataToString];
//        //            AppDelegate *delegate = (AppDelegate *) [UIApplication sharedApplication].delegate;
//        //            delegate.myInfo = user;
//        //            if(user.imToken){
//        //                [LoginWithRC loginRongCloud:user.imToken];
//        //            }
//        if ([[receivedDic allKeys] containsObject:@"loginState"]) {
//            if ([receivedDic[@"loginState"] intValue]) {
//                NSLog(@"登录成功-------");
//            }
//        }
//        
//        //            [self heartStart];
//        
//        //心跳
//        static dispatch_once_t onceToken;
//        dispatch_once(&onceToken, ^{
//            dispatch_queue_t queue = dispatch_queue_create("heart", NULL);
//            dispatch_async(queue, ^{
//                while (1) {
//                    
//                    [NSThread sleepForTimeInterval:20.0f];
//                    [self heartStart];
//                }
//            });
//            
//        });
//    }
//    
//}
//
//// 心跳，接收到心跳请求时回复
//- (void)heartStart{
//    
//    NSMutableData *sendData = [NSMutableData data];
//    //    [sendData appendStringToData:self.token];
//    [sendData appendShortToData:2010];
//    NSDictionary *receivedDic = [[BaseNetManager sharedManager] sendDataToServer:sendData];
//    NSLog(@"心跳一下 >>>%@",receivedDic);
//}
//
//- (void)stopHeart{
//    
//}
//
//- (BOOL)autoLogin{
//    if ([[BaseNetManager sharedManager] isLogin]) {
//        //        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"登录状态" message:@"现在为登录状态，你可以退出登录" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"退出登录", nil];
//        //        alert.cancelButtonIndex = 0;
//        //        //显示AlertView
//        //        [alert show];
//        return YES;
//    }else{
//        NSString *phoneNumber = [[A0SimpleKeychain keychain] stringForKey:@"userAccount"];
//        NSString *password = [[A0SimpleKeychain keychain] stringForKey:@"userPassword"];
//        if (phoneNumber.length == 11 && password.length > 5) {
//            [[BaseNetManager sharedManager] loginWithAccount:phoneNumber AndPassword:password];
//            if (self.token == nil) {
//                return NO;
//            }
//            return YES;
//        }else{
//            [[BaseNetManager sharedManager] outLine];
//            return NO;
//        }
//    }
//    return NO;
//}
//- (void)outLine{
//    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
//    delegate.myInfo = nil;
//    [[A0SimpleKeychain keychain] deleteEntryForKey:@"userAccount"];
//    [[A0SimpleKeychain keychain] deleteEntryForKey:@"userPassword"];
//    UIViewController *appRootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
//    UIViewController *topVC = appRootVC;
//    while (topVC.presentedViewController) {
//        topVC = topVC.presentedViewController;
//    }
//    LoginViewController *loginVC = [[LoginViewController alloc]init];
//    UINavigationController *navi = [[UINavigationController alloc] initWithRootViewController:loginVC];
//    //    if (!self.hasShowLoginVC) {
//    [topVC presentViewController:navi animated:YES completion:^{
//        //            self.hasShowLoginVC = YES;
//    }];
//    //    }
//    
//}
//
//- (UIViewController *)appRootViewController
//{
//    UIViewController *appRootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
//    UIViewController *topVC = appRootVC;
//    while (topVC.presentedViewController) {
//        topVC = topVC.presentedViewController;
//    }
//    return topVC;
//}
//
//- (BOOL)isLogin{
//    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
//    if (delegate.myInfo) {
//        return YES;
//    }else{
//        return NO;
//    }
//}
//
////保存数据到NSUserDefaults
//-(void)saveNSUserDefaults:(NSArray *)array{
//    //将上述数据全部存储到NSUserDefaults中
//    
//    //    DDLogVerbose(@"用户信息=%@",dictionary);
//    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
//    
//    [userDefaults setObject:array forKey:@"newsTagArray"];
//    //这里建议同步存储到磁盘中，但是不是必须的
//    [userDefaults synchronize];
//}


@end
