//
//  DiscoverTableCell.m
//  同行
//
//  Created by Duke on 2017/3/3.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "DiscoverTableCell.h"

@implementation DiscoverTableCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
