//
//  DiscoverViewController.m
//  同行
//
//  Created by Duke on 2017/3/1.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "DiscoverViewController.h"
#import "RequestManager.h"
#import "DiscoverTableCell.h"

@interface DiscoverViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *headerArray;
@property (nonatomic, strong) NSMutableArray *nearArray;
@property (nonatomic, strong) NSMutableArray *healthArray;
@property (nonatomic, strong) NSMutableArray *shopArray;
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UIView *healthView;
@property (nonatomic, strong) UIView *shopView;

@end

@implementation DiscoverViewController
static NSString *identifier = @"discoverCell";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.titleLabel.text = @"发现";
    
    [self loadImageWithUrl:@"http://lz.lzhealth.com.cn/api/best-sellers/?"];
    
    self.view.backgroundColor = [UIColor colorWithRed:246/255.0 green:246/255.0 blue:246/255.0 alpha:1.0];
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-108) style:UITableViewStyleGrouped];
    self.tableView = tableView;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    tableView.delegate = self;
    tableView.dataSource = self;
    [tableView registerNib:[UINib nibWithNibName:@"DiscoverTableCell" bundle:nil] forCellReuseIdentifier:identifier];
    [self.view addSubview:tableView];
    
}

#pragma mark --- 请求数据
// 请求数据
- (void)loadImageWithUrl:(NSString *)url {
    self.headerArray = [NSMutableArray array];
    // 开始请求
    [RequestManager GET:url parameters:nil responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
        
        NSLog(@"header :%@",responseObject);
        [self.headerArray addObjectsFromArray:responseObject];
        [self loadShopWithUrl:@"http://lz.lzhealth.com.cn/api/partners/?"];
    } failure:^(NSError *error) {
        // 数据请求失败，暂时不做处理
    }];
}
- (void)loadShopWithUrl:(NSString *)url {
    self.shopArray = [NSMutableArray array];
    // 开始请求
    [RequestManager GET:url parameters:nil responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
        
        NSLog(@"shop :%@",responseObject);
        [self.shopArray addObjectsFromArray:[responseObject objectForKey:@"results"]];
        [self loadNearWithUrl:@"http://lz.lzhealth.com.cn/api/most-reviewed-products/?"];
    } failure:^(NSError *error) {
        // 数据请求失败，暂时不做处理
    }];
}
- (void)loadNearWithUrl:(NSString *)url {
    self.nearArray = [NSMutableArray array];
    // 开始请求
    [RequestManager GET:url parameters:nil responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
        
        NSLog(@"near :%@",responseObject);
        [self.nearArray addObjectsFromArray:responseObject];
        [self loadHealthWithUrl:@"http://lz.lzhealth.com.cn/api/featured/?filter=financial-top"];
    } failure:^(NSError *error) {
        // 数据请求失败，暂时不做处理
    }];
}
- (void)loadHealthWithUrl:(NSString *)url {
    self.healthArray = [NSMutableArray array];
    // 开始请求
    [RequestManager GET:url parameters:nil responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
        
        NSLog(@"health--- %@",responseObject);
        [self.healthArray addObjectsFromArray:[responseObject objectForKey:@"products"]];
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        // 数据请求失败，暂时不做处理
    }];
}

#pragma mark --- 搭建界面
- (void)setupTodayShopView{
    
    CGFloat width = (ScreenWidth - 30) / 2.0;
//    CGFloat height = 180*self.scaleX;
    for (int i=0; i<self.headerArray.count; i++) {
        NSDictionary *imageDic = self.headerArray[i];
        NSArray *imageArray = [imageDic objectForKey:@"store_images"];
        UIView *singleView = [[UIView alloc] init];
//        UIImageView *todayImage = [[UIImageView alloc] initWithImage:[self getImageFromURL:imageArray[0]]];
        UIImageView *todayImage = [[UIImageView alloc] init];
        [todayImage sd_setImageWithURL:imageArray[0] placeholderImage:[UIImage imageNamed:@"footerImageView"]];
        UILabel *label = [[UILabel alloc] init];
        label.text = imageDic[@"name"];
        label.font = [UIFont systemFontOfSize:10.0];
        label.textColor = [UIColor whiteColor];
        UIButton *productBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        productBtn.tag = 100+i;
        [productBtn addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.headerView addSubview:singleView];
        [singleView addSubview:todayImage];
        [singleView addSubview:label];
        [singleView addSubview:productBtn];
        
        [productBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [singleView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10+(10+width)*i);
            make.width.mas_equalTo(width);
            make.top.mas_equalTo(10);
            make.bottom.mas_equalTo(-10);
        }];
        [todayImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.bottom.mas_equalTo(0);
            make.height.mas_equalTo(30*self.scaleX);
        }];
    }
}

- (void)setupHealthView{
    
    CGFloat width = (ScreenWidth - 30) / 2.0;
    CGFloat height = 360*self.scaleX / 2.0;
    for (int i=0; i<self.healthArray.count; i++) {
        
        NSDictionary *imageDic = self.healthArray[i];
        NSArray *imageArray = [imageDic objectForKey:@"images"];
        UIView *singleView = [[UIView alloc] init];
//        UIImageView *todayImage = [[UIImageView alloc] initWithImage:[self getImageFromURL:imageArray[0]]];
        UIImageView *todayImage = [[UIImageView alloc] init];
        [todayImage sd_setImageWithURL:imageArray[0] placeholderImage:[UIImage imageNamed:@"footerImageView"]];
        UILabel *label = [[UILabel alloc] init];
        label.text = imageDic[@"title"];
        label.font = [UIFont systemFontOfSize:10.0];
        label.textColor = [UIColor whiteColor];
        UIButton *productBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        productBtn.tag = 102+i;
        [productBtn addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.healthView addSubview:singleView];
        [singleView addSubview:todayImage];
        [singleView addSubview:label];
        [singleView addSubview:productBtn];
        
        [productBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [singleView mas_makeConstraints:^(MASConstraintMaker *make) {
            if (i==0) {
                make.left.mas_equalTo(10);
                make.top.mas_equalTo(10);
                make.bottom.mas_equalTo(-10);
            }else{
                make.left.mas_equalTo(20+width);
                make.top.mas_equalTo((i-1)*(10+height)+10);
                make.height.mas_equalTo(height);
            }
            make.width.mas_equalTo(width);
            
        }];
        [todayImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.bottom.mas_equalTo(0);
            make.height.mas_equalTo(30*self.scaleX);
        }];
    }
}

- (void)setupNewShopView{
    
    CGFloat width = (ScreenWidth - 40) / 3.0;
    CGFloat height = 360*self.scaleX / 3.0;
    CGFloat margin = 10;
    for (int i=0; i<self.shopArray.count; i++) {
        
        NSDictionary *imageDic = self.shopArray[i];
        NSArray *imageArray = [imageDic objectForKey:@"store_images"];
        UIView *singleView = [[UIView alloc] init];
//        UIImageView *todayImage = [[UIImageView alloc] initWithImage:[self getImageFromURL:imageArray[0]]];
        UIImageView *todayImage = [[UIImageView alloc] init];
        [todayImage sd_setImageWithURL:imageArray[0] placeholderImage:[UIImage imageNamed:@"footerImageView"]];
        UILabel *label = [[UILabel alloc] init];
        label.text = imageDic[@"name"];
        label.font = [UIFont systemFontOfSize:10.0];
        label.textColor = [UIColor whiteColor];
        UIButton *productBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        productBtn.tag = 200+i;
        [productBtn addTarget:self action:@selector(clickShopBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.shopView addSubview:singleView];
        [singleView addSubview:todayImage];
        [singleView addSubview:label];
        [singleView addSubview:productBtn];
        
        [productBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [singleView mas_makeConstraints:^(MASConstraintMaker *make) {
            if (i < 3) {
                make.left.mas_equalTo(margin + (margin+width)*i);
                make.top.mas_equalTo(15);
            }else if(i>2 && i<6){
                make.left.mas_equalTo(margin + (margin+width)*(i-3));
                make.top.mas_equalTo(15+margin+height);
            }else{
                make.left.mas_equalTo(margin + (margin+width)*(i-6));
                make.top.mas_equalTo(15+(margin+height)*2);
            }
            make.width.mas_equalTo(width);
            make.height.mas_equalTo(height);
        }];
        [todayImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.bottom.mas_equalTo(0);
            make.height.mas_equalTo(30*self.scaleX);
        }];
    }
}

#pragma mark --- 获取图片
-(UIImage *) getImageFromURL:(NSString *)fileURL {
    UIImage *result;
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fileURL]];
    result = [UIImage imageWithData:data];
    return result;
}

#pragma mark --- 点击事件
- (void)clickBtn:(UIButton *)btn{
    long tag = btn.tag - 100;
    NSLog(@"click %ld",tag);
}

- (void)clickShopBtn:(UIButton *)btn{
    long tag = btn.tag - 200;
    NSLog(@"click Shop %ld",tag);
}


#pragma mark --- UITableViewDataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 3;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DiscoverTableCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if (indexPath.section == 0) {
        NSDictionary *dataDic = self.nearArray[indexPath.row];
        NSArray *imageArray = [dataDic objectForKey:@"images"];

        [cell.headImageView sd_setImageWithURL:imageArray[0] placeholderImage:[UIImage imageNamed:@"footerImageView"]];
        cell.nameLabel.text = dataDic[@"title"];
        cell.priceLabel.text = [NSString stringWithFormat:@"￥%d", [[dataDic objectForKey:@"purchase_info"][@"price"] intValue]];
        cell.sortLabel.text = dataDic[@"category"];
        cell.saleLabel.text = [NSString stringWithFormat:@"月销:%d",[dataDic[@"sales_per_month"] intValue]];
        return cell;
    }
    
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 345*self.scaleX)];
        UILabel *label = [[UILabel alloc] init];
        label.backgroundColor = [UIColor whiteColor];
        label.text = @"今日旺店";
        label.font = [UIFont systemFontOfSize:13.0];
        label.textAlignment = NSTextAlignmentCenter;

        self.headerView = [[UIView alloc] init];
        self.headerView.backgroundColor = [UIColor whiteColor];
        UILabel *nearLabel = [[UILabel alloc] init];
        nearLabel.backgroundColor = [UIColor whiteColor];
        nearLabel.text = @"附近热评榜";
        nearLabel.font = [UIFont systemFontOfSize:13.0];
        nearLabel.textAlignment = NSTextAlignmentCenter;
        
        [headerView addSubview:label];
        [headerView addSubview:self.headerView];
        [headerView addSubview:nearLabel];

        [nearLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.mas_equalTo(0);
            make.height.mas_equalTo(70*self.scaleX);
        }];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.mas_equalTo(0);
            make.height.mas_equalTo(50*self.scaleX);
        }];
        [self.headerView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(0);
            make.top.equalTo(label.mas_bottom).with.offset(0);
            make.bottom.equalTo(nearLabel.mas_top).with.offset(-5);
        }];
        
        [self setupTodayShopView];
        
        return headerView;
    }
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 460*self.scaleX)];
    UILabel *label = [[UILabel alloc] init];
    label.backgroundColor = [UIColor whiteColor];
    label.text = @"新店入驻";
    label.font = [UIFont systemFontOfSize:13.0];
    label.textAlignment = NSTextAlignmentCenter;
    self.shopView = [[UIView alloc] init];
    self.shopView.backgroundColor = [UIColor whiteColor];
    
    [headerView addSubview:label];
    [headerView addSubview:self.shopView];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.mas_equalTo(0);
        make.height.mas_equalTo(50*self.scaleX);
    }];
    [self.shopView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.top.equalTo(label.mas_bottom).with.offset(0);
    }];
    
    [self setupNewShopView];
    return headerView;

}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (section == 0) {
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 470*self.scaleX)];
        UILabel *label = [[UILabel alloc] init];
        label.backgroundColor = [UIColor whiteColor];
        label.text = @"优选健康";
        label.font = [UIFont systemFontOfSize:13.0];
        label.textAlignment = NSTextAlignmentCenter;
        self.healthView = [[UIView alloc] init];
        self.healthView.backgroundColor = [UIColor whiteColor];
        
        [footerView addSubview:label];
        [footerView addSubview:self.healthView];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(0);
            make.top.mas_equalTo(5);
            make.height.mas_equalTo(50*self.scaleX);
        }];
        [self.healthView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(0);
            make.top.equalTo(label.mas_bottom).with.offset(0);
            make.bottom.mas_equalTo(-5);
        }];
        
        [self setupHealthView];
        
        return footerView;
    }
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 80*self.scaleX)];
    footerView.backgroundColor = [UIColor whiteColor];
    UIImageView *bgImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"footerImageView"]];
    [footerView addSubview:bgImageView];
    
    [bgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(160*self.scaleX, 60*self.scaleX));
    }];
    
    return footerView;

}

#pragma mark --- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if(section == 0){
        return 345*self.scaleX;
    }
    return 460*self.scaleX;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if(section == 0){
        return 470*self.scaleX;
    }
    return 80*self.scaleX;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 1) {
        return 0;
    }
    return 120*self.scaleX;
}


@end
