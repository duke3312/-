//
//  OrderViewController.m
//  同行
//
//  Created by Duke on 2017/3/1.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "OrderViewController.h"

@interface OrderViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentControl;
@property (weak, nonatomic) IBOutlet UIImageView *noOrderImage;
@property (nonatomic, strong) NSMutableArray *orderList;

@end

@implementation OrderViewController
static NSString *identifier = @"UserInfoCell";

- (NSMutableArray *)orderList{
    if (!_orderList) {
        _orderList = [NSMutableArray array];
    }
    return _orderList;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.titleLabel.text = @"我的订单";
    self.segmentControl.tintColor = [UIColor clearColor];//去掉颜色,现在整个segment都看不见
    NSDictionary* selectedTextAttributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:13],
                                             NSForegroundColorAttributeName: [UIColor colorWithRed:114/255.0 green:198/255.0 blue:252/255.0 alpha:1.0f]};
    [self.segmentControl setTitleTextAttributes:selectedTextAttributes forState:UIControlStateSelected];//设置文字属性
    NSDictionary* unselectedTextAttributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:13],
                                               NSForegroundColorAttributeName: [UIColor colorWithRed:40/255.0 green:42/255.0 blue:48/255.0 alpha:1.0f]};
    [self.segmentControl setTitleTextAttributes:unselectedTextAttributes forState:UIControlStateNormal];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    self.tableView = tableView;
    tableView.backgroundColor = [UIColor clearColor];
    //    tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 15);
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.delegate = self;
    tableView.dataSource = self;
    [tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:identifier];
//    [tableView registerNib:[UINib nibWithNibName:@"UserInfoTableCell" bundle:nil] forCellReuseIdentifier:identifier];
    
    if (self.orderList.count != 0) {
        self.noOrderImage.hidden = YES;
    }
    
}


#pragma mark --- UITableViewDataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.orderList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
//    cell.selectionStyle = UITableViewCellSelectionStyleNone;
//    cell.leftImage.image = [UIImage imageNamed:self.iconArray[indexPath.row]];
//    cell.leftLabel.text = [NSString stringWithFormat:@"%@",self.titleArray[indexPath.row]];
//    cell.numLabel.hidden = YES;
//    if (indexPath.row == 0) {
//        cell.rightLabel.text = @"让身边的朋友也能享受健康的服务";
//    }else if (indexPath.row == 1){
//        cell.rightLabel.text = @"更努力的为大众健康服务";
//    }else if (indexPath.row == 3){
//        cell.numLabel.hidden = NO;
//        cell.rightImageView.hidden = YES;
//        cell.numLabel.text = @"1.0.2(16)";
//    }
    return cell;
}

#pragma mark --- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 72*self.scaleY;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
