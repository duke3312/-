//
//  UserInfoTableCell.h
//  同行
//
//  Created by Duke on 2017/3/1.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserInfoTableCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *leftImage;
@property (weak, nonatomic) IBOutlet UILabel *leftLabel;
@property (weak, nonatomic) IBOutlet UILabel *rightLabel;
@property (weak, nonatomic) IBOutlet UIImageView *rightImageView;
@property (weak, nonatomic) IBOutlet UILabel *numLabel;


@end
