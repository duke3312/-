//
//  SettingViewController.m
//  同行
//
//  Created by Duke on 2017/3/2.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "SettingViewController.h"
#import "UserInfoTableCell.h"

@interface SettingViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UIView *topBgView;
@property (nonatomic, strong) UIView *bottomView;
@property (nonatomic, strong) NSArray *iconArray;
@property (nonatomic, strong) NSArray *titleArray;

@end

@implementation SettingViewController
static NSString *identifier = @"UserInfoCell";

- (NSArray *)iconArray{
    if (!_iconArray) {
        _iconArray = [NSArray arrayWithObjects: @"userCenter_concernTeamIcon", @"userCenter_collectionIcon", @"userCenter_historyIcon", @"userCenter_earningIcon", nil];
    }
    return _iconArray;
}
- (NSArray *)titleArray{
    if (!_titleArray)
        _titleArray = [NSArray arrayWithObjects:@"邀请好友", @"给我们鼓励", @"清除缓存", @"版本号", nil];
    return _titleArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.titleLabel.text = @"设置";
    [self initWithHeadTopView];
    
    //返回按钮
    naviItem *backItem = [naviItem makeSingleItem];
    backItem.backImage.image = [UIImage imageNamed:@"backIcon_small"];
    [backItem addTarget:self action:@selector(clickBackButton)];
    // 调整 leftBarButtonItem 在 iOS7 下面的位置
    UIBarButtonItem *backNavigationItem = [[UIBarButtonItem alloc] initWithCustomView:backItem];
    if(([[[UIDevice currentDevice] systemVersion] floatValue]>=7.0?20:0)){
        UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
        negativeSpacer.width = -10;
        self.navigationItem.leftBarButtonItems = @[negativeSpacer, backNavigationItem];
    }else{
        self.navigationItem.leftBarButtonItem = backNavigationItem;
    }
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    self.tableView = tableView;
    tableView.backgroundColor = [UIColor whiteColor];
    //    tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 15);
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.delegate = self;
    tableView.dataSource = self;
    //    [tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:identifier];
    [tableView registerNib:[UINib nibWithNibName:@"UserInfoTableCell" bundle:nil] forCellReuseIdentifier:identifier];
    
    tableView.sectionHeaderHeight = 180*self.scaleX;
    [tableView setTableHeaderView:self.topBgView];
    [self.view addSubview:tableView];
    
}

#pragma mark --- 初始化视图
- (void)initWithHeadTopView{
    
    self.topBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 180*self.scaleX)];
    self.topBgView.backgroundColor = [UIColor colorWithRed:247/255.0 green:247/255.0 blue:247/255.0 alpha:1.0];

    UIImageView *topImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"headerImage"]];
    
    [self.view addSubview:self.topBgView];
    [self.topBgView addSubview:topImageView];
    
    [topImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_equalTo(0);
        make.height.mas_equalTo(174*self.scaleX);
    }];
}

#pragma mark --- 点击事件
- (void)clickBackButton{
    
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)clickQuitBtn{
    
}

#pragma mark --- UITableViewDataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UserInfoTableCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.leftImage.image = [UIImage imageNamed:self.iconArray[indexPath.row]];
    cell.leftLabel.text = [NSString stringWithFormat:@"%@",self.titleArray[indexPath.row]];
    cell.numLabel.hidden = YES;
    if (indexPath.row == 0) {
        cell.rightLabel.text = @"让身边的朋友也能享受健康的服务";
    }else if (indexPath.row == 1){
        cell.rightLabel.text = @"更努力的为大众健康服务";
    }else if (indexPath.row == 3){
        cell.numLabel.hidden = NO;
        cell.rightImageView.hidden = YES;
        cell.numLabel.text = @"1.0.2(16)";
    }
    return cell;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *topBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight - 64 -180*self.scaleX - 72*4*self.scaleX)];
    topBgView.backgroundColor = [UIColor whiteColor];
    UIView *btnView = [[UIView alloc] init];
    btnView.backgroundColor = [UIColor whiteColor];
    btnView.layer.masksToBounds = YES;
    btnView.layer.cornerRadius = 4;
    btnView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    btnView.layer.borderWidth = 1;
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    [btn setTitle:@"退出当前账号" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:12.0];
    [btn addTarget:self action:@selector(clickQuitBtn) forControlEvents:UIControlEventTouchUpInside];
    
    [topBgView addSubview:btnView];
    [btnView addSubview:btn];
    
    [btnView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(-90*self.scaleX);
        make.centerX.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(180*self.scaleX, 68*self.scaleX));
    }];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    return topBgView;
}


#pragma mark --- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return ScreenHeight - 180*self.scaleX - 72*4*self.scaleX - 64;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 72*self.scaleY;
}


@end
