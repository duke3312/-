//
//  UserViewController.m
//  同行
//
//  Created by Duke on 2017/3/1.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "UserViewController.h"
#import "UserInfoTableCell.h"
#import "SettingViewController.h"
#import "VIPCardViewController.h"
#import "InsuraceViewController.h"
#import "MyCollectionController.h"
#import "MessageViewController.h"
#import "ShopingCarViewController.h"
#import "MyCommentViewController.h"
#import "AddressManagerController.h"
#import "MerchantViewController.h"
#import "AboutUsViewController.h"

@interface UserViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UIView *topBgView;
@property (nonatomic, strong) UIView *funView;
@property (nonatomic, strong) UIView *bottomView;
@property (nonatomic, strong) NSArray *iconArray;
@property (nonatomic, strong) NSArray *titleArray;

@end

@implementation UserViewController
static NSString *identifier = @"UserInfoCell";

- (NSArray *)iconArray{
    if (!_iconArray) {
        _iconArray = [NSArray arrayWithObjects: @"userCenter_concernTeamIcon", @"userCenter_collectionIcon", @"userCenter_historyIcon", @"userCenter_earningIcon", @"userCenter_accountIcon", @"userCenter_integralIcon",@"userCenter_ticketIcon", nil];
    }
    return _iconArray;
}
- (NSArray *)titleArray{
    if (!_titleArray)
        _titleArray = [NSArray arrayWithObjects:@"我的消息", @"我的购物车", @"我的点评", @"地址管理", @"我是商家", @"联系客服", @"关于我们", nil];
    return _titleArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.text = @"杜文庆";
    [self initWithHeadTopView];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44) style:UITableViewStylePlain];
    self.tableView = tableView;
    tableView.backgroundColor = [UIColor whiteColor];
//    tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 15);
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.delegate = self;
    tableView.dataSource = self;
//    [tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:identifier];
    [tableView registerNib:[UINib nibWithNibName:@"UserInfoTableCell" bundle:nil] forCellReuseIdentifier:identifier];
    
    tableView.sectionHeaderHeight = 290*self.scaleX;
    [tableView setTableHeaderView:self.topBgView];
    [self.view addSubview:tableView];
    
    UIView *bgView = [[UIView alloc] init];
    bgView.backgroundColor = [UIColor colorWithRed:114/255.0 green:198/255.0 blue:252/255.0 alpha:1.0f];
    [self.view addSubview:bgView];
    [bgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.mas_equalTo(0);
        make.height.mas_equalTo(64);
    }];
//    [self.tableView setContentOffset:CGPointMake(0,0) animated:NO];//从顶部显示
    
    //右侧按钮
    naviItem *recordItem = [naviItem makeSingleItem];
    [recordItem.itemBtn setImage:[UIImage imageNamed:@"userCenter_settingIcon"] forState:UIControlStateNormal];
    [recordItem addTarget:self action:@selector(clickSettingBtn)];
    // 调整 leftBarButtonItem 在 iOS7 下面的位置
    UIBarButtonItem *rightNavigationItem = [[UIBarButtonItem alloc] initWithCustomView:recordItem];
    if(([[[UIDevice currentDevice] systemVersion] floatValue]>=7.0?20:0)){
        UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
        negativeSpacer.width = -18;
        self.navigationItem.rightBarButtonItems = @[negativeSpacer, rightNavigationItem];
    }else{
        self.navigationItem.rightBarButtonItem = rightNavigationItem;
    }
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
  
    //设置导航栏透明
    self.navigationController.navigationBar.translucent = YES;
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"透明图片.png"] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.clipsToBounds = YES; //去掉白线
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];

//    [self.navigationController.navigationBar setTranslucent:NO];
//    // 设置导航栏背景颜色
//    [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:114/255.0 green:198/255.0 blue:252/255.0 alpha:1.00f]];
//    [self.navigationController.navigationBar setShadowImage:[UIImage imageNamed:@"透明图片"]];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];

    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@""] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.clipsToBounds = NO; //去掉白线
//    [self.navigationController.navigationBar setTranslucent:NO]; //坐标从（0.64）开始
//    // 设置导航栏背景颜色
//    [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:250/255.0 green:250/255.0 blue:250/255.0 alpha:1.00f]];
    [self.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
    
}

#pragma mark --- 初始化视图
- (void)initWithHeadTopView{
    
    self.topBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 290*self.scaleX)];
    self.topBgView.backgroundColor = [UIColor colorWithRed:114/255.0 green:198/255.0 blue:252/255.0 alpha:1.0f];
    //头像视图
    UIView *headView = [[UIView alloc] init];
    headView.backgroundColor = [UIColor whiteColor];
    headView.layer.cornerRadius = 52*self.scaleX;
    UIButton *headBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [headBtn addTarget:self action:@selector(clickChangeUserInfoBtn) forControlEvents:UIControlEventTouchUpInside];
    UIImageView *headImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Found_press"]];
//    if ([self takeUserInfoToUserdefaults] != nil) {
//        headImage.image = [self takeUserInfoToUserdefaults];
//    }else{
//        [headImage sd_setImageWithURL:[NSURL URLWithString:myInfo.headUrl]];
//    }
    headImage.layer.masksToBounds = YES;
    headImage.layer.cornerRadius = 50*self.scaleX;
    
    [self.view addSubview:self.topBgView];
    [self.topBgView addSubview:headView];
    [headView addSubview:headImage];
    [headView addSubview:headBtn];
    
    [headImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(100*self.scaleX, 100*self.scaleX));
    }];
    [headBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(104*self.scaleX, 104*self.scaleX));
    }];
    [headView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(40*self.scaleX);
        make.centerX.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(104*self.scaleX, 104*self.scaleX));
    }];
    
    //功能卡
    UIView *funcView = [[UIView alloc] init];
    funcView.backgroundColor = [UIColor colorWithRed:75/255.0 green:184/255.0 blue:254/255.0 alpha:1];
    [self.topBgView addSubview:funcView];
    [funcView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.bottom.mas_equalTo(0);
        make.height.mas_equalTo(120*self.scaleX);
    }];
    NSArray *titleArr = [NSArray arrayWithObjects:@"我的会员卡", @"我的保险", @"我的收藏", nil];
    NSArray *imageArr = [NSArray arrayWithObjects:@"userCenter_concernIcon", @"userCenter_fansIcon", @"userCenter_settingIcon", nil];
    for (int i=0; i<3; i++) {
        CGFloat width = self.view.frame.size.width / 3.0;
        UIView *singleView = [[UIView alloc] init];
        UIView *rightLineView = [[UIView alloc] init];
        rightLineView.backgroundColor = [UIColor colorWithRed:232/255.0 green:232/255.0 blue:232/255.0 alpha:1];
        UIButton *funBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [funBtn setTitle:titleArr[i] forState:UIControlStateNormal];
        [funBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [funBtn setImage:[UIImage imageNamed:imageArr[i]] forState:UIControlStateNormal];
        funBtn.titleLabel.font = [UIFont systemFontOfSize:12];
        funBtn.tag = 100 + i;
        [funBtn addTarget:self action:@selector(clickFunctionBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        [funcView addSubview:singleView];
        [singleView addSubview:funBtn];
        
        [singleView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(i*width);
            make.width.mas_equalTo(width);
            make.top.bottom.mas_equalTo(0);
        }];
        [funBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(width, 65*self.scaleX));
        }];
        //图片和文字上下居中显示
        funBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        [funBtn setTitleEdgeInsets:UIEdgeInsetsMake(0 ,-funBtn.imageView.frame.size.width, -funBtn.imageView.frame.size.height-3, 0)];//文字距离上边框的距离增加imageView的高度，距离左边框减少imageView的宽度，距离下边框和右边框距离不变
        [funBtn setImageEdgeInsets:UIEdgeInsetsMake(-funBtn.titleLabel.frame.size.height-3, 0, 0, -funBtn.titleLabel.frame.size.width)];//图片距离右边框距离减少图片的宽度，其它不边
        if (i != 2) {
            [singleView addSubview:rightLineView];
            [rightLineView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerY.mas_equalTo(0);
                make.right.mas_equalTo(0);
                make.width.mas_equalTo(0.5);
                make.top.bottom.mas_equalTo(0);
            }];
        }
    }
    
}

#pragma mark --- ScrollDelegate
//-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
////    NSLog(@"%f",self.tableView.contentOffset.y);
//    if (self.tableView.contentOffset.y < -64) {
//        self.tableView.backgroundColor = [UIColor colorWithRed:114/255.0 green:198/255.0 blue:252/255.0 alpha:1.0f];
//    } else if (self.tableView.contentOffset.y > -64){
//        self.tableView.backgroundColor = [UIColor whiteColor];
//    }
//}


//- (void)initWithBottomView{
//
//    UIButton *quitBtn = [UIButton buttonWithType:UIButtonTypeSystem];
//    quitBtn.backgroundColor = color3;
//    quitBtn.layer.cornerRadius = 4;
//    [quitBtn setTitle:@"退出登录" forState:UIControlStateNormal];
//    [quitBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    quitBtn.titleLabel.font = [UIFont systemFontOfSize:16.0];
//    [quitBtn addTarget:self action:@selector(clickQuitLoginBtn) forControlEvents:UIControlEventTouchUpInside];
//    [self.bottomView addSubview:quitBtn];
//    [quitBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.center.mas_equalTo(0);
//        make.size.mas_equalTo(CGSizeMake(294*self.scaleX, 48*self.scaleX));
//    }];
//
//}

#pragma mark --- 从本地获取头像
- (UIImage *)takeUserInfoToUserdefaults{
//    
//    UserModel *myInfo = [UserModel getMyInfo];
//    NSString *key = [NSString stringWithFormat:@"%ld",myInfo.ID];
    UIImage *image;
//    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
//    NSData *infoData;
//    infoData = [userDefaults dataForKey:key];
//    image = [UIImage imageWithData:infoData];
    return image;
}

#pragma mark --- 点击事件
- (void)clickSettingBtn{
    SettingViewController *changeVC = [[SettingViewController alloc] init];
    changeVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:changeVC animated:YES];
}

- (void)clickChangeUserInfoBtn{
    
    [[[UIAlertView alloc] initWithTitle:nil message:@"无法修改个人信息......" delegate:self cancelButtonTitle:nil otherButtonTitles:@"好的", nil] show];
//    ChangeInfoViewController *changeVC = [[ChangeInfoViewController alloc] init];
//    changeVC.hidesBottomBarWhenPushed = YES;
//    [self.navigationController pushViewController:changeVC animated:YES];
//        UINavigationController *navi = [[UINavigationController alloc] initWithRootViewController:changeVC];
//        [self presentViewController:navi animated:YES completion:nil];
}

- (void)clickFunctionBtn:(UIButton *)btn{
    long int tag = btn.tag - 100;
    
    if (tag == 0) {
        VIPCardViewController *concernVC = [[VIPCardViewController alloc] init];
        concernVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:concernVC animated:YES];
    }else if (tag == 1) {
        InsuraceViewController *fansVC = [[InsuraceViewController alloc] init];
        fansVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:fansVC animated:YES];
    }else{
        //设置
        MyCollectionController *settingVC = [[MyCollectionController alloc]init];
        settingVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:settingVC animated:YES];
    }
    
}

#pragma mark --- UITableViewDataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 7;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UserInfoTableCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
//    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
//    cell.contentView.backgroundColor = [UIColor whiteColor];
    
//    if (indexPath.section == 1) {
        cell.leftImage.image = [UIImage imageNamed:self.iconArray[indexPath.row]];
        cell.leftLabel.text = [NSString stringWithFormat:@"%@",self.titleArray[indexPath.row]];
    if (indexPath.row == 4) {
        cell.rightLabel.text = @"马上入驻群众健康，获取最优推荐";
    }
//        cell.cellLineView.hidden = NO;
//        if (indexPath.row == 0) {
//            UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, self.view.bounds.size.width - 10, 50*self.scaleY) byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:CGSizeMake(4, 4)];
//            CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
//            maskLayer.frame = CGRectMake(0, 0, self.view.bounds.size.width - 10, 50*self.scaleY);
//            maskLayer.path = maskPath.CGPath ;
//            cell.bgView.layer.mask = maskLayer;
//        }else if (indexPath.row == 2){
//            cell.cellLineView.hidden = YES;
//            UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, self.view.bounds.size.width - 10, 50*self.scaleY) byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight cornerRadii:CGSizeMake(4, 4)];
//            CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
//            maskLayer.frame = CGRectMake(0, 0, self.view.bounds.size.width - 10, 50*self.scaleY);
//            maskLayer.path = maskPath.CGPath;
//            cell.bgView.layer.mask = maskLayer;
//        }else{
//            
//        }
//    }else{
//        
//        if (indexPath.section == 2) {
//            cell.iconImage.image = [UIImage imageNamed:self.iconArray[indexPath.row+3]];
//            cell.titleLabel.text = [NSString stringWithFormat:@"%@",self.titleArray[indexPath.row+3]];
//        }else{
//            cell.iconImage.image = [UIImage imageNamed:self.iconArray[indexPath.row+5]];
//            cell.titleLabel.text = [NSString stringWithFormat:@"%@",self.titleArray[indexPath.row+5]];
//        }
//        if (indexPath.row == 0) {
//            cell.cellLineView.hidden = NO;
//            UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, self.view.bounds.size.width - 10, 50*self.scaleY) byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:CGSizeMake(4, 4)];
//            CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
//            maskLayer.frame = CGRectMake(0, 0, self.view.bounds.size.width - 10, 50*self.scaleY);
//            maskLayer.path = maskPath.CGPath;
//            cell.bgView.layer.mask = maskLayer;
//        }else if (indexPath.row == 1){
//            cell.cellLineView.hidden = YES;
//            UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, self.view.bounds.size.width - 10, 50*self.scaleY) byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight cornerRadii:CGSizeMake(4, 4)];
//            CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
//            maskLayer.frame = CGRectMake(0, 0, self.view.bounds.size.width - 10, 50*self.scaleY);
//            maskLayer.path = maskPath.CGPath;
//            cell.bgView.layer.mask = maskLayer;
//        }
//    }
    return cell;
}

#pragma mark --- UITableViewDelegate
//- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
//    if (section == 0) {
//        UIView *topBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 208*self.scaleY)];
//        self.topBgView = topBgView;
//        topBgView.backgroundColor = [UIColor whiteColor];
//        //        [self.view addSubview:topBgView];
//        UIView *topLineView = [[UIView alloc] init];
//        topLineView.backgroundColor = color2;
//        [topBgView addSubview:topLineView];
//        [topLineView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.right.bottom.mas_equalTo(0);
//            make.height.mas_equalTo(0.5);
//        }];
//        [self initWithHeadTopView];
//        
//        return topBgView;
//    }
//    return [[UIView alloc] initWithFrame:CGRectZero];
//}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    switch (indexPath.row) {
        case 0:{
            MessageViewController *myTeamVC = [[MessageViewController alloc]init];
            myTeamVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:myTeamVC animated:YES];
        }
            break;
        case 1:{
            ShopingCarViewController *myTeamVC = [[ShopingCarViewController alloc]init];
            myTeamVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:myTeamVC animated:YES];
        }
            break;
        case 2:{
            MyCommentViewController *myTeamVC = [[MyCommentViewController alloc]init];
            myTeamVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:myTeamVC animated:YES];
        }
            break;
        case 3:{
            AddressManagerController *myTeamVC = [[AddressManagerController alloc]init];
            myTeamVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:myTeamVC animated:YES];
        }
            break;
        case 4:{
            MerchantViewController *myTeamVC = [[MerchantViewController alloc]init];
            myTeamVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:myTeamVC animated:YES];
        }
            break;
        case 5:{
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"联系客服" message:@"400-106-8000" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *manAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
                NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"tel://400-106-8000"]];
                [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:^(BOOL success) {
                    if (success) {
                        
                    }
                }];
                
            }];
            UIAlertAction *cancleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                [alert dismissViewControllerAnimated:YES completion:^{
                    
                }];
            }];
            [alert addAction:manAction];
            [alert addAction:cancleAction];
            [self presentViewController:alert animated:YES completion:nil];
        }
            break;
        case 6:{
            AboutUsViewController *myTeamVC = [[AboutUsViewController alloc]init];
            myTeamVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:myTeamVC animated:YES];
        }
            break;
            
        default:
            break;
    }
}
//-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
//    if (section == 0) {
//        return 208*self.scaleY;
//    }
//    return 0.5;
//}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 72*self.scaleY;
}


@end
