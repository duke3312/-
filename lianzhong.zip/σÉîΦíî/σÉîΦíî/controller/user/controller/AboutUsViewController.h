//
//  AboutUsViewController.h
//  同行
//
//  Created by Duke on 2017/3/2.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "BaseViewController.h"

@interface AboutUsViewController : BaseViewController

@end
