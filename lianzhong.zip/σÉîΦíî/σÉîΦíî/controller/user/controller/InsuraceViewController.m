//
//  InsuraceViewController.m
//  同行
//
//  Created by Duke on 2017/3/2.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "InsuraceViewController.h"

@interface InsuraceViewController ()

@end

@implementation InsuraceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.titleLabel.text = @"健康保险";
    //返回按钮
    naviItem *backItem = [naviItem makeSingleItem];
    backItem.backImage.image = [UIImage imageNamed:@"backIcon_small"];
    [backItem addTarget:self action:@selector(clickBackButton)];
    // 调整 leftBarButtonItem 在 iOS7 下面的位置
    UIBarButtonItem *backNavigationItem = [[UIBarButtonItem alloc] initWithCustomView:backItem];
    if(([[[UIDevice currentDevice] systemVersion] floatValue]>=7.0?20:0)){
        UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
        negativeSpacer.width = -10;
        self.navigationItem.leftBarButtonItems = @[negativeSpacer, backNavigationItem];
    }else{
        self.navigationItem.leftBarButtonItem = backNavigationItem;
    }
    
}
#pragma mark --- 点击事件
- (void)clickBackButton{
    [self.navigationController popViewControllerAnimated:YES];
}
    

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
