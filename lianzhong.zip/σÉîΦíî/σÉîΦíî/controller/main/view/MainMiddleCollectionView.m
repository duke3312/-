//
//  MainMiddleCollectionView.m
//  同行
//
//  Created by Duke on 2017/3/2.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "MainMiddleCollectionView.h"
#import "MiddleCollectionCell.h"

@interface MainMiddleCollectionView ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (nonatomic,strong) UICollectionView *collectionView;
@property float scaleX;

@end

@implementation MainMiddleCollectionView
static NSString *identifier = @"middleItem";


// 初始化 设置背景颜色透明点，然后加载子视图
- (instancetype)initWithFrame:(CGRect)frame {
    if (self == [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor colorWithRed:246/255.0 green:246/255.0 blue:246/255.0 alpha:1.0];
        AppDelegate *myDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        self.scaleX = myDelegate.autoSizeScaleY;
        [self addsubviews];
//        [_collectionView reloadData];
    }
    return self;
}
- (UICollectionView *)collectionView
{
    if (_collectionView == nil) {
        CGFloat height = (self.frame.size.height - 45)/2.0;
        CGFloat width = (self.frame.size.width - 24)/2.0;
        UICollectionViewFlowLayout *flow = [[UICollectionViewFlowLayout alloc] init];
        flow.itemSize = CGSizeMake(width, height);
        flow.minimumLineSpacing = 12;
        flow.minimumInteritemSpacing = 8;
        
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 5, ScreenWidth, self.frame.size.height - 10) collectionViewLayout:flow];
        _collectionView.backgroundColor = [UIColor whiteColor];
        _collectionView.scrollEnabled = NO;
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.showsHorizontalScrollIndicator = NO;
        _collectionView.showsVerticalScrollIndicator = NO;
        [_collectionView registerNib:[UINib nibWithNibName:@"MiddleCollectionCell" bundle:nil] forCellWithReuseIdentifier:identifier];
        [self addSubview:_collectionView];
    }
    return _collectionView;
}

// 第一次加载的时候刷新collectionView
- (void)setDataSource:(NSArray *)dataSource{
    
    _dataSource = dataSource;
    [self.collectionView reloadData];
}

// 加载子视图
- (void)addsubviews{
    
    [self addSubview:_collectionView];
}
#pragma makr - collectionView delegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    MiddleCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    NSLog(@"dataSource : %@",self.dataSource);
    NSDictionary *dic = self.dataSource[indexPath.row];
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//        dispatch_async(dispatch_get_main_queue(), ^{
//            UIImageView *image = [[UIImageView alloc] init];
//            [image sd_setImageWithURL:[NSURL URLWithString:dic[@"image"]] placeholderImage:[UIImage imageNamed:@""]];
//            cell.bgImageView.image = image.image;
//        });
//    });
    
    cell.bgImageView.image = [self getImageFromURL:dic[@"image"]];
    return cell;
}

- (UIImage *) getImageFromURL:(NSString *)fileURL {
    UIImage *result;
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fileURL]];
    result = [UIImage imageWithData:data];
    return result;
}

// 点击item的时候
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    [self selectedHero:indexPath.row];
}

- (void)selectedHero:(NSInteger)index{
    if (self.delegate && [self.delegate respondsToSelector:@selector(selectedHero:)]) {
        [self.delegate selectedHero:index];
    }
}

#pragma mark  定义整个CollectionViewCell与整个View的间距
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(15, 8, 15, 8);//（上、左、下、右）
}
#pragma mark  设置CollectionViewCell是否可以被点击
- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}


@end
