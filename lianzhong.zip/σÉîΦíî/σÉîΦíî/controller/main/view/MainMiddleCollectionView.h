//
//  MainMiddleCollectionView.h
//  同行
//
//  Created by Duke on 2017/3/2.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MainMiddleDelegate <NSObject>

- (void)selectedHero:(NSInteger)index;

@end

@interface MainMiddleCollectionView : UIView

@property (nonatomic,weak) id<MainMiddleDelegate>delegate;
@property (nonatomic,strong) NSArray *dataSource;

@end
