//
//  ProductDetailController.m
//  同行
//
//  Created by Duke on 2017/3/5.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "ProductDetailController.h"
#import "LBBannerView.h"
#import "RequestManager.h"

@interface ProductDetailController ()<UIWebViewDelegate,UIScrollViewDelegate>

@property (nonatomic, strong) UIScrollView *scrollView;
@property (strong, nonatomic) UIWebView *webView;
@property (strong, nonatomic) NSDictionary *dataDic;
@property (nonatomic, strong) UIView *bgView;
@property (nonatomic, strong) UIView *midView;
@property (nonatomic, strong) UIView *netView;
@property (nonatomic, strong) UIView *bottomView;
@property (nonatomic, strong) UIView *buyView;
@property (nonatomic, assign) CGFloat webHeight;
@property (nonatomic, strong) NSMutableArray *funcArray;

@end

@implementation ProductDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadData];
    self.view.backgroundColor = [UIColor colorWithRed:246/255.0 green:246/255.0 blue:246/255.0 alpha:1];
    self.titleLabel.text = @"商品详情";
    //返回按钮
    naviItem *backItem = [naviItem makeSingleItem];
    backItem.backImage.image = [UIImage imageNamed:@"backIcon_small"];
    [backItem addTarget:self action:@selector(clickBackButton)];
    // 调整 leftBarButtonItem 在 iOS7 下面的位置
    UIBarButtonItem *backNavigationItem = [[UIBarButtonItem alloc] initWithCustomView:backItem];
    if(([[[UIDevice currentDevice] systemVersion] floatValue]>=7.0?20:0)){
        UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
        negativeSpacer.width = -10;
        self.navigationItem.leftBarButtonItems = @[negativeSpacer, backNavigationItem];
    }else{
        self.navigationItem.leftBarButtonItem = backNavigationItem;
    }
    
}
- (void)loadData{
    
    [RequestManager GET:self.dataStr parameters:nil responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
        NSLog(@"dataDic = %@",responseObject);
        self.dataDic = responseObject;
        [self setupMainView];
        
//        NSLog(@"xml --->>> %@",[self.dataDic objectForKey:@"description"]);
    } failure:^(NSError *error) {
        // 数据请求失败，暂时不做处理
    }];
}
- (void)loadFuncData{
    
    [self.funcArray removeAllObjects];
    NSLog(@"%@",[NSString stringWithFormat:@"%@recommended-products/?",self.dataStr]);
    [RequestManager GET:@"http://lz.lzhealth.com.cn/api/products/293/recommended-products/?" parameters:nil responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
        NSLog(@"funcData = %@",responseObject);
        self.funcArray = [NSMutableArray arrayWithArray:responseObject];
        [self setupBottomView];
    } failure:^(NSError *error) {
        // 数据请求失败，暂时不做处理
    }];
}

#pragma mark --- 搭建界面
- (void)setupMainView{
    
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    self.scrollView = scrollView;
    scrollView.delegate = self;
    scrollView.contentSize = CGSizeMake(ScreenWidth, 1475*self.scaleX+100);
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.bounces = NO;
    scrollView.pagingEnabled = NO;
//    scrollView.backgroundColor = [UIColor redColor];
    [self.view addSubview:scrollView];
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.mas_equalTo(0);
        make.width.mas_equalTo(ScreenWidth);
        make.centerX.mas_equalTo(0);
        make.bottom.mas_equalTo(-65*self.scaleX);
    }];
    
    self.buyView = [[UIView alloc] init];
    self.buyView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.buyView];
    [self.buyView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.height.mas_equalTo(65*self.scaleX);
    }];
    [self setupBuyView];
    
    self.bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 1475*self.scaleX+100)];
    [scrollView addSubview:self.bgView];
    UIView *topView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 620*self.scaleX)];
    [self.bgView addSubview:topView];
    NSMutableArray *imageArray = [[NSMutableArray alloc] initWithArray:self.dataDic[@"images"]];
    if (imageArray.count <= 1) {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 390*self.scaleX)];
        [imageView sd_setImageWithURL:imageArray[0]];
        [topView addSubview: imageView];
    }else{
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            LBBannerView *bannerView = [[LBBannerView alloc] initViewWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 390*self.scaleX) autoPlayTime:3.0f imagesArray:imageArray clickCallBack:^(NSInteger index) {
    //            NSLog(@"点击了第%ld张图片",index);
            }];
            dispatch_async(dispatch_get_main_queue(), ^{
                [topView addSubview: bannerView];
            });
        });
    }
    
    UIView *titleView = [[UIView alloc] init];
    titleView.backgroundColor = [UIColor whiteColor];
    NSArray *titleArray = [self.dataDic objectForKey:@"attributes"];
    for (int i=0; i<titleArray.count; i++) {
        
        UILabel *titleLabel = [[UILabel alloc] init];
        titleLabel.numberOfLines = 0;
        titleLabel.font = [UIFont systemFontOfSize:15.0];
        titleLabel.text = self.dataDic[@"title"];
        
        UILabel *funcLabel = [[UILabel alloc] init];
        funcLabel.textColor = [UIColor lightGrayColor];
        funcLabel.font = [UIFont systemFontOfSize:12.0];
        
        UILabel *ruleLabel = [[UILabel alloc] init];
        ruleLabel.textColor = [UIColor lightGrayColor];
        ruleLabel.font = [UIFont systemFontOfSize:12.0];
        
        NSDictionary *priceDic = [self.dataDic objectForKey:@"purchase_info"];
        UILabel *newPriceLabel = [[UILabel alloc] init];
        newPriceLabel.textColor = [UIColor colorWithRed:1 green:13/155.0 blue:13/255.0 alpha:1.0];
        newPriceLabel.font = [UIFont systemFontOfSize:16.0];
        newPriceLabel.text = [NSString stringWithFormat:@"￥%d",[priceDic[@"price"] intValue]];
        UILabel *oldPriceLabel = [[UILabel alloc] init];
        oldPriceLabel.textColor = [UIColor lightGrayColor];
        oldPriceLabel.font = [UIFont systemFontOfSize:11.0];
        oldPriceLabel.text = [NSString stringWithFormat:@"￥%d",[priceDic[@"price_retail"] intValue]];
        
        UIView *lineView = [[UIView alloc] init];
        lineView.backgroundColor = [UIColor lightGrayColor];
        if ([oldPriceLabel.text isEqualToString:@""]) {
            lineView.hidden = YES;
        }
        
        UILabel *saleLabel = [[UILabel alloc] init];
        saleLabel.textColor = [UIColor lightGrayColor];
        saleLabel.font = [UIFont systemFontOfSize:13.0];
        saleLabel.text = [NSString stringWithFormat:@"月销: %@",self.dataDic[@"sales_per_month"]];
        
        if (i == 0){
            funcLabel.text = [NSString stringWithFormat:@"%@: %@",titleArray[0][@"name"], titleArray[0][@"value"]];
        }else if (i == 2){
            ruleLabel.text = [NSString stringWithFormat:@"%@: %@",titleArray[3][@"name"], titleArray[3][@"value"]];
        }
        
        [titleView addSubview:titleLabel];
        [titleView addSubview:funcLabel];
        [titleView addSubview:ruleLabel];
        [titleView addSubview:newPriceLabel];
        [titleView addSubview:oldPriceLabel];
        [titleView addSubview:saleLabel];
        [titleView addSubview:lineView];
        
        [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(20);
            make.top.mas_equalTo(0);
            make.right.mas_equalTo(-20);
            make.height.mas_equalTo(80*self.scaleX);
        }];
        [funcLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(titleLabel.mas_left);
            make.right.mas_equalTo(titleLabel.mas_right);
            make.top.equalTo(titleLabel.mas_bottom).with.offset(0);
            make.height.mas_equalTo(40*self.scaleX);
        }];
        [ruleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(titleLabel.mas_left);
            make.right.mas_equalTo(titleLabel.mas_right);
            make.top.equalTo(funcLabel.mas_bottom).with.offset(0);
            make.height.mas_equalTo(40*self.scaleX);
        }];
        [newPriceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(titleLabel.mas_left);
            make.bottom.mas_equalTo(-15);
        }];
        [oldPriceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(newPriceLabel.mas_right).with.offset(15);
            make.bottom.mas_equalTo(-15);
        }];
        [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(oldPriceLabel);
            make.width.mas_equalTo(oldPriceLabel.mas_width);
            make.left.mas_equalTo(oldPriceLabel.mas_left);
            make.height.mas_equalTo(1);
        }];
        [saleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.bottom.mas_equalTo(-15);
        }];
    }
    [topView addSubview:titleView];
    [titleView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.top.mas_equalTo(390*self.scaleX);
    }];
    
    UIView *midView = [[UIView alloc] init];
    midView.backgroundColor = [UIColor colorWithRed:246/255.0 green:246/255.0 blue:246/255.0 alpha:1];
    self.midView = midView;
    UILabel *serveLabel = [[UILabel alloc] init];
    serveLabel.textColor = [UIColor blackColor];
    serveLabel.backgroundColor = [UIColor whiteColor];
    serveLabel.font = [UIFont systemFontOfSize:14.0];
    
    UILabel *chargeLabel = [[UILabel alloc] init];
    chargeLabel.backgroundColor = [UIColor whiteColor];
    chargeLabel.textColor = [UIColor blackColor];
    chargeLabel.font = [UIFont systemFontOfSize:14.0];
    if (titleArray.count >= 3) {
        serveLabel.text = [NSString stringWithFormat:@"      %@  %@",titleArray[2][@"name"], titleArray[2][@"value"]];
        [self changeLabelTextColor:serveLabel];
    }else if (titleArray.count >= 2){
        chargeLabel.text = [NSString stringWithFormat:@"      %@  %@",titleArray[1][@"name"], titleArray[1][@"value"]];
        [self changeLabelTextColor:chargeLabel];
    }
    
    NSDictionary *shopDic = [self.dataDic objectForKey:@"partner_info"];
    UILabel *shopLabel = [[UILabel alloc] init];
    shopLabel.backgroundColor = [UIColor whiteColor];
    shopLabel.font = [UIFont systemFontOfSize:14.0];
    shopLabel.text = [NSString stringWithFormat:@"      %@",shopDic[@"name"]];
    
    [self.bgView addSubview:midView];
    [midView addSubview:serveLabel];
    [midView addSubview:chargeLabel];
    [midView addSubview:shopLabel];
    [serveLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.top.mas_equalTo(0);
        make.height.mas_equalTo(65*self.scaleX);
    }];
    [chargeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(serveLabel.mas_left);
        make.right.mas_equalTo(serveLabel.mas_right);
        make.top.equalTo(serveLabel.mas_bottom).with.offset(0.5);
        make.height.mas_equalTo(65*self.scaleX);
    }];
    [shopLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(chargeLabel.mas_bottom).with.offset(5);
        make.height.mas_equalTo(70*self.scaleX);
        make.left.right.mas_equalTo(0);
    }];
    [midView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.top.equalTo(titleView.mas_bottom).with.offset(5);
        make.height.mas_equalTo(145);
    }];
    
    UIWebView *webView = [[UIWebView alloc] init];
    self.webView = webView;
    webView.scrollView.scrollEnabled = NO;
    webView.delegate = self;
    webView.dataDetectorTypes = UIDataDetectorTypeAll;
    webView.scrollView.showsHorizontalScrollIndicator = NO;
    //@"<html>\n<head lang=\"en\">\n  <meta charset=\"UTF-8\">\n  <title></title>\n  <style>\n    body {\n      width: 100%;\n      margin: 0;\n      font-size: 15px;\n      white-space: normal;\n      word-break: break-all;\n      overflow-x: hidden;\n    }\n\n    img {\n      width: 100%;\n      margin-top: 20px;\n    }\n\n    p {\n      margin: 5px 15px;\n    }\n  </style>\n</head>\n<body>\n<p><img src=\"http://image.suning.cn/uimg/sop/commodity/127475701014145599879164_x.jpg\" alt=\"\" width=\"750\" height=\"1046\" /><img src=\"http://image.suning.cn/uimg/sop/commodity/313192968721582754709800_x.jpg\" alt=\"\" width=\"750\" height=\"1047\" /><img src=\"http://image.suning.cn/uimg/sop/commodity/150500576017815570218053_x.jpg\" alt=\"\" width=\"750\" height=\"1046\" /><img src=\"http://image.suning.cn/uimg/sop/commodity/805443681354953524447600_x.jpg\" alt=\"\" width=\"750\" height=\"1046\" /><img src=\"http://image.suning.cn/uimg/sop/commodity/139743283916322220643555_x.jpg\" alt=\"\" width=\"750\" height=\"1047\" /></p>\r\n<p><img src=\"http://image.suning.cn/uimg/sop/commodity/196408546505142275216400_x.jpg\" alt=\"\" width=\"750\" height=\"1046\" /><img src=\"http://image.suning.cn/uimg/sop/commodity/982772417208192214055780_x.jpg\" alt=\"\" width=\"750\" height=\"1046\" /><img src=\"http://image.suning.cn/uimg/sop/commodity/222348923121685741396540_x.jpg\" alt=\"\" width=\"750\" height=\"1046\" /><img src=\"http://image.suning.cn/uimg/sop/commodity/529673440174769662430300_x.jpg\" alt=\"\" width=\"750\" height=\"1047\" /><img src=\"http://image.suning.cn/uimg/sop/commodity/179722317918479233504765_x.jpg\" alt=\"\" width=\"750\" height=\"1046\" /></p>\n</body>\n</html>\n"
    [webView loadHTMLString:[self.dataDic objectForKey:@"description"] baseURL:nil];
    [self.bgView addSubview:webView];
    [webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.top.equalTo(midView.mas_bottom).with.offset(0);
        make.height.mas_equalTo(100);
    }];
    
    UIView *commentView = [[UIView alloc] init];
    commentView.backgroundColor = [UIColor whiteColor];
    UILabel *commentLabel = [[UILabel alloc] init];
    commentLabel.font = [UIFont systemFontOfSize:13.0];
    commentLabel.text = [NSString stringWithFormat:@"评价"];
    UILabel *noLabel = [[UILabel alloc] init];
    noLabel.textColor = [UIColor lightGrayColor];
    noLabel.textAlignment = NSTextAlignmentCenter;
    noLabel.font = [UIFont systemFontOfSize:11.0];
    noLabel.text = [NSString stringWithFormat:@"暂无评价"];
    
    [self.bgView addSubview:commentView];
    [commentView addSubview:commentLabel];
    [commentView addSubview:noLabel];
    
    [commentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(16);
        make.right.mas_equalTo(0);
        make.top.mas_equalTo(0);
        make.height.mas_equalTo(65*self.scaleX);
    }];
    [noLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.bottom.mas_equalTo(-10);
    }];
    [commentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.top.equalTo(webView.mas_bottom).with.offset(0);
        make.height.mas_equalTo(100*self.scaleX);
    }];

    
    UIView *bottomView = [[UIView alloc] init];
    bottomView.backgroundColor = [UIColor whiteColor];
    self.bottomView = bottomView;
    [self.bgView addSubview:bottomView];
    [bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.bottom.mas_equalTo(-0.5);
        make.top.equalTo(commentView.mas_bottom).with.offset(5);
    }];
    [self loadFuncData];
}

- (void)setupBuyView{
    
    NSArray *textArray = [NSArray arrayWithObjects:@"联系客服", @"收藏", @"购物车", @"立即预约", nil];
    NSArray *images = [NSArray arrayWithObjects:@"team_detail_callMe", @"shortVideo_collectNormalIcon", @"shortVideo_historyIcon", @"", nil];
    //功能卡
    for (int i=0; i<textArray.count; i++) {
        CGFloat width = (ScreenWidth-250*self.scaleX) / 3.0;
        
        UIView *singleView = [[UIView alloc] init];
        UIButton *funBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [funBtn setTitle:textArray[i] forState:UIControlStateNormal];
        [funBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [funBtn setImage:[UIImage imageNamed:images[i]] forState:UIControlStateNormal];
        funBtn.titleLabel.font = [UIFont systemFontOfSize:12];
        if (i == 1) {
            [funBtn setImage:[UIImage imageNamed:@"shortVideo_collectionIcon"] forState:UIControlStateSelected];
        }else if(i == 3){
            [funBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            funBtn.backgroundColor = [UIColor colorWithRed:75/255.0 green:184/255.0 blue:254/255.0 alpha:1];
        }
        funBtn.tag = 500 + i;
        [funBtn addTarget:self action:@selector(clickBuyBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.buyView addSubview:singleView];
        [singleView addSubview:funBtn];
        
        [singleView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(i*width);
            make.top.bottom.mas_equalTo(0);
            if (i == 3) {
                make.right.mas_equalTo(0);
            }else{
                make.width.mas_equalTo(width);
            }
        }];
        [funBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        //图片和文字上下居中显示
        funBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        [funBtn setTitleEdgeInsets:UIEdgeInsetsMake(0 ,-funBtn.imageView.frame.size.width, -funBtn.imageView.frame.size.height-5, 0)];//文字距离上边框的距离增加imageView的高度，距离左边框减少imageView的宽度，距离下边框和右边框距离不变
        [funBtn setImageEdgeInsets:UIEdgeInsetsMake(-funBtn.titleLabel.frame.size.height-5, 0, 0, -funBtn.titleLabel.frame.size.width)];//图片距离右边框距离减少图片的宽度，其它不边
    }
}

//推荐
- (void)setupBottomView{
    
    CGFloat width = (ScreenWidth - 40) / 3.0;
    CGFloat height = 220*self.scaleX;
    CGFloat margin = 10;
    UILabel *commentLabel = [[UILabel alloc] init];
    commentLabel.font = [UIFont systemFontOfSize:13.0];
    commentLabel.text = [NSString stringWithFormat:@"猜你喜欢"];
    [self.bottomView addSubview:commentLabel];
    [commentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(0);
        make.top.mas_equalTo(0);
        make.height.mas_equalTo(60*self.scaleX);
    }];
    UIView *funcView = [[UIView alloc] init];
    [self.bottomView addSubview:funcView];
    [funcView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.top.equalTo(commentLabel.mas_bottom).with.offset(0);
        make.height.mas_equalTo(height * 2+10);
    }];
    
    for (int i=0; i<self.funcArray.count; i++) {
        
        NSDictionary *imageDic = self.funcArray[i];
        NSArray *imageArray = [imageDic objectForKey:@"images"];
        
        UIView *singleView = [[UIView alloc] init];
        UIImageView *todayImage = [[UIImageView alloc] init];
        if (imageArray.count != 0) {
            [todayImage sd_setImageWithURL:imageArray[0] placeholderImage:[UIImage imageNamed:@"footerImageView"]];
        }
        UILabel *label = [[UILabel alloc] init];
        label.numberOfLines = 0;
        label.text = imageDic[@"title"];
        label.font = [UIFont systemFontOfSize:13.0];
        
        NSDictionary *priceDic = [imageDic objectForKey:@"purchase_info"];
        UILabel *priceLabel = [[UILabel alloc] init];
        priceLabel.text = [NSString stringWithFormat:@"￥%d",[priceDic[@"price_retail"] intValue]];
        priceLabel.font = [UIFont systemFontOfSize:13.0];
        UIButton *productBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        productBtn.tag = 200+i;
        [productBtn addTarget:self action:@selector(clickShopBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        [funcView addSubview:singleView];
        [singleView addSubview:todayImage];
        [singleView addSubview:label];
        [singleView addSubview:priceLabel];
        [singleView addSubview:productBtn];
        
        [productBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [singleView mas_makeConstraints:^(MASConstraintMaker *make) {
            if (i < 3) {
                make.left.mas_equalTo(margin + (margin+width)*i);
                make.top.mas_equalTo(0);
            }else{
                make.left.mas_equalTo(margin + (margin+width)*(i-3));
                make.top.mas_equalTo(margin+height);
            }
            make.width.mas_equalTo(width);
            make.height.mas_equalTo(height);
        }];
        [todayImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.mas_equalTo(0);
            make.height.mas_equalTo(120*self.scaleX);
        }];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(0);
            make.top.equalTo(todayImage.mas_bottom).with.offset(0);
            make.height.mas_equalTo(60*self.scaleX);
        }];
        [priceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(0);
            make.top.equalTo(label.mas_bottom).with.offset(5);
        }];
    }
}

#pragma mark --- label显示不同颜色
- (void)changeLabelTextColor:(UILabel *)label{
    
    NSMutableAttributedString *attributeStr = [[NSMutableAttributedString alloc] initWithString:label.text];
    [attributeStr addAttribute:NSForegroundColorAttributeName value:[UIColor lightGrayColor] range: NSMakeRange(0, 9)];
    label.attributedText = attributeStr;
}

#pragma mark --- UIWebViewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
//    self.progressView.hidden = YES;
//    [self.activityView stopAnimating];
    self.webHeight = [webView.scrollView contentSize].height;
    NSLog(@"height = %f",self.webHeight);
    [self.view setNeedsUpdateConstraints];
    self.scrollView.contentSize = CGSizeMake(ScreenWidth, 1475*self.scaleX+self.webHeight);
    self.bgView.frame = CGRectMake(0, 0, ScreenWidth, 1475*self.scaleX + self.webHeight);
    [self.webView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.top.equalTo(self.midView.mas_bottom).with.offset(0);
        make.height.mas_equalTo(self.webHeight);
    }];
//    [self initWithCommentView];
    
}

#pragma mark --- 点击事件
- (void)clickBackButton{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)clickShopBtn:(UIButton *)btn{
    long tag = btn.tag - 200;
    NSLog(@"click tag ->%ld",tag);
}

- (void)clickBuyBtn:(UIButton *)btn{
    long tag = btn.tag - 500;
    NSLog(@"click tag ->%ld",btn.tag - 500);
    if (tag == 0) {
        NSDictionary *phoneDic = [self.dataDic objectForKey:@"partner_info"];
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"联系客服" message:phoneDic[@"phone_number"] preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *manAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",phoneDic[@"phone_number"]]];
            [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:^(BOOL success) {
                
            }];
        }];
        UIAlertAction *cancleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            [alert dismissViewControllerAnimated:YES completion:^{
                
            }];
        }];
        [alert addAction:manAction];
        [alert addAction:cancleAction];
        [self presentViewController:alert animated:YES completion:nil];
    }else if (tag == 1) {
        btn.selected = !btn.selected;
    }
}

@end
