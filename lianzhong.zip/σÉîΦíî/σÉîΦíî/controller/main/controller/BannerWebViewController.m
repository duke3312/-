//
//  BannerWebViewController.m
//  同行
//
//  Created by Duke on 2017/3/5.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "BannerWebViewController.h"

@interface BannerWebViewController ()<UIWebViewDelegate>

@property (strong, nonatomic) UIWebView *webView;

@end

@implementation BannerWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.titleLabel.text = @"商品详情";
    //返回按钮
    naviItem *backItem = [naviItem makeSingleItem];
    backItem.backImage.image = [UIImage imageNamed:@"backIcon_small"];
    [backItem addTarget:self action:@selector(clickBackButton)];
    // 调整 leftBarButtonItem 在 iOS7 下面的位置
    UIBarButtonItem *backNavigationItem = [[UIBarButtonItem alloc] initWithCustomView:backItem];
    if(([[[UIDevice currentDevice] systemVersion] floatValue]>=7.0?20:0)){
        UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
        negativeSpacer.width = -10;
        self.navigationItem.leftBarButtonItems = @[negativeSpacer, backNavigationItem];
    }else{
        self.navigationItem.leftBarButtonItem = backNavigationItem;
    }
    
    UIWebView *webView = [[UIWebView alloc] init];
    self.webView = webView;
    webView.delegate = self;
    webView.scrollView.showsHorizontalScrollIndicator = NO;
    // @"http://news.sina.com.cn/w/zx/2016-11-01/doc-ifxxfysn8304478.shtml"
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://123.151.139.59:80/api/products/468/?format=api"]];
    [webView loadRequest:request];
    [self.view addSubview:webView];
    [webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.left.mas_equalTo(0);
        make.width.mas_equalTo(ScreenWidth);
    }];
    
}

#pragma mark --- UIWebViewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
//    self.progressView.hidden = YES;
//    [self.activityView stopAnimating];
//    CGFloat webViewHeight = [webView.scrollView contentSize].height;
//    NSLog(@"height = %f",webViewHeight);
//    [self initWithCommentView];
    
}


- (void)clickBackButton{
    [self.navigationController popViewControllerAnimated:YES];
}


@end
