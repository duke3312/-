//
//  GuessLikeViewController.m
//  同行
//
//  Created by Duke on 2017/3/6.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "GuessLikeViewController.h"
#import "DiscoverTableCell.h"
#import "RequestManager.h"
#import "ProductDetailController.h"

@interface GuessLikeViewController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@end

@implementation GuessLikeViewController
static NSString *identifier = @"discoverCell";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.titleLabel.text = @"猜你喜欢";
    //返回按钮
    naviItem *backItem = [naviItem makeSingleItem];
    backItem.backImage.image = [UIImage imageNamed:@"backIcon_small"];
    [backItem addTarget:self action:@selector(clickBackButton)];
    // 调整 leftBarButtonItem 在 iOS7 下面的位置
    UIBarButtonItem *backNavigationItem = [[UIBarButtonItem alloc] initWithCustomView:backItem];
    if(([[[UIDevice currentDevice] systemVersion] floatValue]>=7.0?20:0)){
        UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                           target:nil action:nil];
        negativeSpacer.width = -10;
        self.navigationItem.leftBarButtonItems = @[negativeSpacer, backNavigationItem];
    }else{
        self.navigationItem.leftBarButtonItem = backNavigationItem;
    }
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-64) style:UITableViewStylePlain];
    self.tableView = tableView;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    tableView.delegate = self;
    tableView.dataSource = self;
    [tableView registerNib:[UINib nibWithNibName:@"DiscoverTableCell" bundle:nil] forCellReuseIdentifier:identifier];
    [self.view addSubview:tableView];
    
}

#pragma mark --- 点击事件
- (void)clickBackButton{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark --- UITableViewDataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.shopArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DiscoverTableCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    NSDictionary *dataDic = self.shopArray[indexPath.row];
    NSArray *imageArray = [dataDic objectForKey:@"images"];
    [cell.headImageView sd_setImageWithURL:imageArray[0] placeholderImage:[UIImage imageNamed:@"footerImageView"]];
    cell.nameLabel.text = dataDic[@"title"];
    cell.priceLabel.text = [NSString stringWithFormat:@"￥%d", [[dataDic objectForKey:@"purchase_info"][@"price"] intValue]];
    cell.sortLabel.text = dataDic[@"category"];
    cell.saleLabel.text = [NSString stringWithFormat:@"月销:%d",[dataDic[@"sales_per_month"] intValue]];
    
    return cell;
}

#pragma mark --- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary *dataDic = self.shopArray[indexPath.row];
    ProductDetailController *concernVC = [[ProductDetailController alloc] init];
    concernVC.dataStr = dataDic[@"url"];
    [self.navigationController pushViewController:concernVC animated:YES];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 122*self.scaleX;
}


@end
