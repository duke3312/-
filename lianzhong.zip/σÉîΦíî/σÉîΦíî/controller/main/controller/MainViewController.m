//
//  MainViewController.m
//  同行
//
//  Created by Duke on 2017/3/1.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "MainViewController.h"
#import "RequestManager.h"
#import "NSString+Addition.h"
#import "LBBannerView.h"
#import "MainTableViewCell.h"
#import "MainMiddleCollectionView.h"
#import "ProductDetailController.h"
#import "GuessLikeViewController.h"

@interface MainViewController ()<UISearchBarDelegate,UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,MainMiddleDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *naviView;
@property (nonatomic, strong) UIView *topBannerView;
@property (nonatomic, strong) UIView *topFuncView;
@property (nonatomic, strong) UIView *topCellView;
@property (nonatomic, strong) UIView *productView;
@property (nonatomic, strong) NSMutableArray *bannerArray;
@property (nonatomic, strong) NSMutableArray *middleArray;
@property (nonatomic, strong) NSMutableArray *bottomArray;
@property (nonatomic, strong) NSMutableArray *funcArray;
@property (nonatomic, strong) NSMutableArray *productArray;
@property (nonatomic, strong) UIPageControl *pageControl;
@property (nonatomic, strong) NSMutableArray *storyArray;

@property (nonatomic, strong) MainMiddleCollectionView *middleView;

@end

@implementation MainViewController
static NSString *identifier = @"mainCell";

- (NSMutableArray *)bannerArray{
    if (!_bannerArray) {
        _bannerArray = [NSMutableArray array];
    }
    return _bannerArray;
}
- (NSMutableArray *)middleArray{
    if (!_middleArray) {
        _middleArray = [NSMutableArray array];
    }
    return _middleArray;
}
- (NSMutableArray *)bottomArray{
    if (!_bottomArray) {
        _bottomArray = [NSMutableArray array];
    }
    return _bottomArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.navigationController.navigationBar.translucent = NO;
//    self.view.frame = CGRectMake(0, -64, ScreenWidth, ScreenHeight+64);
    
    [self setupMainView];
    
    self.productArray = [NSMutableArray array];
    self.storyArray = [NSMutableArray array];
    [self loadNewData];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    self.edgesForExtendedLayout = UIRectEdgeBottom;
    //隐藏导航栏
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault; //状态栏
    [self.navigationController setNavigationBarHidden:YES];
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    //设置导航栏
    [self.navigationController setNavigationBarHidden:NO];
}
#pragma mark --- 搭建界面
- (void)setupMainView{
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-49) style:UITableViewStyleGrouped];
    self.tableView = tableView;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    tableView.delegate = self;
    tableView.dataSource = self;
    [tableView registerNib:[UINib nibWithNibName:@"MainTableViewCell" bundle:nil] forCellReuseIdentifier:identifier];
    [self.view addSubview:tableView];
    [self setupSearchItem];
}

#pragma mark --- 搜索栏
- (void)setupSearchItem{
    
    self.naviView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 64)];
    self.naviView.backgroundColor = [UIColor clearColor];
    //搜索栏
    UIView *searchView = [[UIView alloc] initWithFrame:CGRectMake(0, 20, ScreenWidth, 44)];
//    searchView.backgroundColor = [UIColor whiteColor];
    UISearchBar *searchBar = [[UISearchBar alloc] init];
    self.searchBar = searchBar;
    searchBar.placeholder = @"搜店铺、商品和服务";
    searchBar.searchBarStyle = UISearchBarStyleProminent;
    searchBar.barTintColor = [UIColor whiteColor];
    searchBar.backgroundColor = [UIColor whiteColor];
    searchBar.layer.masksToBounds = YES;
    searchBar.layer.cornerRadius = 14;
    searchBar.layer.borderColor = [UIColor lightGrayColor].CGColor;
    searchBar.layer.borderWidth = 0.5;
//    self.navigationItem.titleView = searchView;
    [self.view addSubview:self.naviView];
    [self.naviView addSubview:searchView];
    [searchView addSubview:searchBar];
    [searchBar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(0);
        make.left.mas_equalTo(15*self.scaleX);
        make.right.mas_equalTo(-15*self.scaleX);
        make.height.mas_equalTo(28);
    }];
}

#pragma mark --- 请求数据

- (void)loadNewData{
    [self loadImageWithUrl:@"http://lz.lzhealth.com.cn/api/ads/?positions=top%2Cmiddle%2Cbottom"];
    
}
// 请求数据
- (void)loadImageWithUrl:(NSString *)url {
    // 开始请求
    [RequestManager GET:url parameters:nil responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
        
        NSLog(@"11111---:%@",responseObject);
        if ([[responseObject allKeys] containsObject:@"top"]) {
            self.bannerArray = [responseObject objectForKey:@"top"];
            self.middleArray = [responseObject objectForKey:@"middle"];
            self.bottomArray = [responseObject objectForKey:@"bottom"];
        }
        [self loadDataWithUrl:@"http://lz.lzhealth.com.cn/api/categories/?filter=%E8%81%94%E4%BC%97"];
    } failure:^(NSError *error) {
        // 数据请求失败，暂时不做处理
    }];
    
}

- (void)loadDataWithUrl:(NSString *)url {
    // 开始请求
    [RequestManager GET:url parameters:nil responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
        self.funcArray = [NSMutableArray arrayWithArray:responseObject];
        NSLog(@"22222---:%@",self.funcArray);
        [self.tableView reloadData];
        [self loadProductDataWithUrl:@"http://lz.lzhealth.com.cn/api/featured/?filter=featured"];
    } failure:^(NSError *error) {
        // 数据请求失败，暂时不做处理
    }];
}

- (void)loadProductDataWithUrl:(NSString *)url {
    // 开始请求
    [RequestManager GET:url parameters:nil responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
        self.productArray = [NSMutableArray arrayWithArray:[responseObject objectForKey:@"products"]];
        NSLog(@"33333---:%@",self.funcArray);
        //        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        //            [self saveFuncImageView];
        //            dispatch_async(dispatch_get_main_queue(), ^{
        [self loadStoryDataWithUrl:@"http://lz.lzhealth.com.cn/api/stores/?latitude=39.95721158947651&longitude=116.3666407466326"];
        //            });
        //        });
    } failure:^(NSError *error) {
        // 数据请求失败，暂时不做处理
    }];
}
- (void)loadStoryDataWithUrl:(NSString *)url {
    // 开始请求
    [RequestManager GET:url parameters:nil responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
        self.storyArray = [NSMutableArray arrayWithArray:responseObject];
        NSLog(@"44444---:%@",self.funcArray);
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        // 数据请求失败，暂时不做处理
    }];
}

#pragma mark --- banner图
- (void)setupBannerView{
    //创建轮播器控件
    NSMutableArray *imageArray = [NSMutableArray array];
    for (int i=0; i<self.bannerArray.count; i++) {
        NSDictionary *dic = self.bannerArray[i];
        NSString *urlStr = dic[@"image"];
        if (![urlStr hasPrefix:@"http://"]) {
            urlStr = [NSString stringWithFormat:@"http://%@",urlStr];
        }
        [imageArray addObject:urlStr];
    }
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        LBBannerView *bannerView = [[LBBannerView alloc] initViewWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 310*self.scaleX) autoPlayTime:3.0f imagesArray:imageArray clickCallBack:^(NSInteger index) {
            NSLog(@"点击了第%ld张图片",index);
            [self clickImageWithIndex:index];
        }];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.topBannerView addSubview: bannerView];
        });
    });
    
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 140*self.scaleX)];
    self.scrollView = scrollView;
    scrollView.delegate = self;
    scrollView.contentSize = CGSizeMake(ScreenWidth * 2, 140*self.scaleX);
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.bounces = NO;
    scrollView.pagingEnabled = YES;
//    scrollView.backgroundColor = [UIColor redColor];
    [self.topFuncView addSubview:scrollView];
    
    //功能卡
    for (int i=0; i<self.funcArray.count; i++) {
        CGFloat width = ScreenWidth / 5.0;
        NSDictionary *dataDic = self.funcArray[i];
        
        UIView *singleView = [[UIView alloc] init];
        singleView.backgroundColor = [UIColor whiteColor];
        UIImageView *imageView = [[UIImageView alloc] init];
        [imageView sd_setImageWithURL:dataDic[@"image"] placeholderImage:[UIImage imageNamed:@"footerImageView"]];
        UILabel *title = [[UILabel alloc] init];
        title.text = dataDic[@"name"];
        title.textColor = [UIColor colorWithRed:40/255.0 green:42/255.0 blue:48/255.0 alpha:1];
        title.font = [UIFont systemFontOfSize:12.0];
        title.textAlignment = NSTextAlignmentCenter;
        
        UIButton *funBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        funBtn.tag = 100 + i;
        [funBtn addTarget:self action:@selector(clickFunctionBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        [scrollView addSubview:singleView];
        [singleView addSubview:funBtn];
        [singleView addSubview:imageView];
        [singleView addSubview:title];
        
        [singleView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(i*width);
            make.width.mas_equalTo(width);
            make.top.mas_equalTo(0);
            make.height.mas_equalTo(140*self.scaleX);
        }];
        [title mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(-10);
            make.centerX.mas_equalTo(0);
            make.height.mas_equalTo(30*self.scaleX);
        }];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(80*self.scaleX, 72*self.scaleX));
            make.bottom.equalTo(title.mas_top).with.offset(0);
        }];
        [funBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(width, 140*self.scaleX));
        }];
    }
    
    //segement
    self.pageControl = [[UIPageControl alloc] init];
    self.pageControl.backgroundColor = [UIColor clearColor];
    self.pageControl.numberOfPages = self.funcArray.count / 5;
    self.pageControl.currentPage = 0;
    self.pageControl.currentPageIndicatorTintColor = [UIColor lightGrayColor];
    self.pageControl.pageIndicatorTintColor = [UIColor colorWithRed:223/255.0 green:223/255.0 blue:223/255.0 alpha:1.0];
    [self.topFuncView addSubview:self.pageControl];
    [self.pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.height.mas_equalTo(20*self.scaleX);
        make.top.equalTo(scrollView.mas_bottom).with.offset(0);
    }];

}

#pragma mark --- 精品推荐
- (void)setupProductView{
    
    CGFloat big_W = ScreenWidth / 2.0;
    CGFloat big_H = 270*self.scaleX / 2.0;
    CGFloat small_W = (ScreenWidth-1) / 4.0;
    
    for (int i=0; i<2; i++) {
        UIView *singleView = [[UIView alloc] init];
        
        if (i == 0) {
            for (int j=0; j<2; j++) {
                NSDictionary *dataDic = self.productArray[j];
                NSDictionary *priceDic = [dataDic objectForKey:@"purchase_info"];
                
                UIView *bigSingle = [[UIView alloc] init];
                bigSingle.backgroundColor = [UIColor whiteColor];
                UIView *midView = [[UIView alloc] init];
                UILabel *nameLabel = [[UILabel alloc] init];
                nameLabel.numberOfLines = 0;
                nameLabel.text = dataDic[@"title"];
                nameLabel.textColor = [UIColor colorWithRed:40/255.0 green:42/255.0 blue:48/255.0 alpha:1.0];
                nameLabel.font = [UIFont systemFontOfSize:14.0];
                UILabel *priceLabel = [[UILabel alloc] init];
                priceLabel.text = [NSString stringWithFormat:@"￥%d",[priceDic[@"price"] intValue]];
                priceLabel.textColor = [UIColor colorWithRed:254/255.0 green:157/255.0 blue:0 alpha:1.0];
                priceLabel.font = [UIFont systemFontOfSize:10.0];
                UIImageView *image = [[UIImageView alloc] init];
                [image sd_setImageWithURL:dataDic[@"images"][0] placeholderImage:[UIImage imageNamed:@"footerImageView"]];
                
//                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//                    UIImage *img = [self getImageFromURL:];
//                    dispatch_async(dispatch_get_main_queue(), ^{
//                        image.image = img;
//                    });
//                });

                UIButton *productBtn = [UIButton buttonWithType:UIButtonTypeSystem];
                productBtn.tag = 200+j;
                [productBtn addTarget:self action:@selector(clickProductBtn:) forControlEvents:UIControlEventTouchUpInside];
                
                [singleView addSubview:bigSingle];
                [bigSingle addSubview:midView];
                [midView addSubview:nameLabel];
                [midView addSubview:priceLabel];
                [midView addSubview:image];
                [bigSingle addSubview:productBtn];
                
                [productBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.edges.mas_equalTo(0);
                }];
                [midView mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.centerY.mas_equalTo(0);
                    make.left.right.mas_equalTo(0);
                    make.height.mas_equalTo(65*self.scaleX);
                }];
                [nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.top.mas_equalTo(0);
                    make.left.mas_equalTo(10);
                    make.size.mas_equalTo(CGSizeMake(120*self.scaleX,56*self.scaleX));
                }];
                [priceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.left.mas_equalTo(10);
                    make.top.equalTo(nameLabel.mas_bottom).with.offset(3);
                }];
                [image mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.centerY.mas_equalTo(0);
                    make.right.mas_equalTo(-12);
                    make.size.mas_equalTo(CGSizeMake(120*self.scaleX, 75*self.scaleX));
                }];
                [bigSingle mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.left.mas_equalTo(j*(big_W+0.5));
                    make.width.mas_equalTo(big_W);
                    make.top.bottom.mas_equalTo(0);
                }];
            }
        }else{
            for (int k=0; k<4; k++) {
                UIView *smallSingle = [[UIView alloc] init];
                smallSingle.backgroundColor = [UIColor whiteColor];
                
                NSDictionary *dataDic = self.productArray[k+2];
                NSDictionary *priceDic = [dataDic objectForKey:@"purchase_info"];
                UILabel *nameLabel = [[UILabel alloc] init];
                nameLabel.text = dataDic[@"title"];
                nameLabel.textColor = [UIColor colorWithRed:40/255.0 green:42/255.0 blue:48/255.0 alpha:1.0];
                nameLabel.font = [UIFont systemFontOfSize:14.0];
                UILabel *priceLabel = [[UILabel alloc] init];
                priceLabel.text = [NSString stringWithFormat:@"￥%d",[priceDic[@"price"] intValue]];
                priceLabel.textColor = [UIColor colorWithRed:254/255.0 green:157/255.0 blue:0 alpha:1.0];
                priceLabel.font = [UIFont systemFontOfSize:10.0];
                UIImageView *image = [[UIImageView alloc] init];
                [image sd_setImageWithURL:dataDic[@"images"][0] placeholderImage:[UIImage imageNamed:@"footerImageView"]];
                UIButton *productBtn = [UIButton buttonWithType:UIButtonTypeSystem];
                productBtn.tag = 202+k;
                [productBtn addTarget:self action:@selector(clickProductBtn:) forControlEvents:UIControlEventTouchUpInside];
                
                [singleView addSubview:smallSingle];
                [smallSingle addSubview:nameLabel];
                [smallSingle addSubview:priceLabel];
                [smallSingle addSubview:image];
                [smallSingle addSubview:productBtn];
                
                [productBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.edges.mas_equalTo(0);
                }];
                [nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.top.mas_equalTo(0);
                    make.left.mas_equalTo(10);
                    make.right.mas_equalTo(0);
                }];
                [priceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.left.mas_equalTo(10);
                    make.height.mas_equalTo(20);
                    make.top.equalTo(nameLabel.mas_bottom).with.offset(0);
                }];
                [image mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.centerX.mas_equalTo(0);
                    make.bottom.mas_equalTo(-12);
                    make.size.mas_equalTo(CGSizeMake(95*self.scaleX, 60*self.scaleX));
                }];
                
                [smallSingle mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.left.mas_equalTo(k*(small_W+0.5));
                    make.width.mas_equalTo(small_W);
                    make.top.bottom.mas_equalTo(0);
                }];
            }
        }
        
        [self.productView addSubview:singleView];
        [singleView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(0);
            make.top.mas_equalTo(i*(big_H + 0.5));
            make.height.mas_equalTo(big_H);
        }];
    }
}

#pragma mark --- 存储图片
//- (void) saveFuncImageView{
//    
//    for (int i=0; i<self.funcArray.count; i++) {
//        NSDictionary *dic = self.funcArray[i];
//        NSString *urlString = dic[@"image"];
//        NSData *data = [NSData dataWithContentsOfURL:[NSURL  URLWithString:urlString]];
//        UIImage *image = [UIImage imageWithData:data]; // 取得图片
//        
//        // 本地沙盒目录
//        NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
//        // 得到本地沙盒中名为"MyImage"的路径，"MyImage"是保存的图片名
//        NSString *imageFilePath = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"funcImage%d@2x.png",i]];
//        // 将取得的图片写入本地的沙盒中，其中0.5表示压缩比例，1表示不压缩，数值越小压缩比例越大
//        BOOL success = [UIImageJPEGRepresentation(image, 0.5) writeToFile:imageFilePath  atomically:YES];
//        if (success){
//            NSLog(@"写入本地成功");
//        }
//    }
//}
//
-(UIImage *) getImageFromURL:(NSString *)fileURL {
    UIImage *result;
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fileURL]];
    result = [UIImage imageWithData:data];
    return result;
//    NSFileManager *fm = [NSFileManager defaultManager];
//    //读取图片
//    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
//    NSString *imageFilePath = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"funcImage%d@2x",index]];
//    NSData *iamgeData = [fm contentsAtPath:imageFilePath];
//    UIImage *savedImage = [[UIImage alloc] initWithData:iamgeData];
//    return savedImage;
}

#pragma mark --- 点击事件
//banner图点击事件
- (void)clickImageWithIndex: (NSInteger) index{
    NSLog(@"点击了%ld图片",index);
    NSDictionary *Dic = self.bannerArray[index];
    if ([[Dic objectForKey:@"url"] hasPrefix:@"http"]) {
//        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[Dic objectForKey:@"url"]]];
        ProductDetailController *concernVC = [[ProductDetailController alloc] init];
        concernVC.hidesBottomBarWhenPushed = YES;
        concernVC.dataStr = Dic[@"url"];
        [self.navigationController pushViewController:concernVC animated:YES];

    }else{
        UIAlertController *alertDialog = [UIAlertController alertControllerWithTitle:nil message:@"功能开发中......" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action){
           
        }];
        
        [alertDialog addAction:okAction];
        // 呈现警告视图
        [self presentViewController:alertDialog animated:YES completion:nil];

    }
}

- (void)clickFunctionBtn:(UIButton *)btn{
    
    long int tag = btn.tag - 100;
    NSLog(@"click num%ld",tag);
//    if (tag == 0) {
//        VIPCardViewController *concernVC = [[VIPCardViewController alloc] init];
//        concernVC.hidesBottomBarWhenPushed = YES;
//        [self.navigationController pushViewController:concernVC animated:YES];
//    }else if (tag == 1) {
//        InsuraceViewController *fansVC = [[InsuraceViewController alloc] init];
//        fansVC.hidesBottomBarWhenPushed = YES;
//        [self.navigationController pushViewController:fansVC animated:YES];
//    }else{
//        //设置
//        MyCollectionController *settingVC = [[MyCollectionController alloc]init];
//        settingVC.hidesBottomBarWhenPushed = YES;
//        [self.navigationController pushViewController:settingVC animated:YES];
//    }

}

#pragma mark --- 点击精品推荐
- (void)clickMoreBtn{
    GuessLikeViewController *concernVC = [[GuessLikeViewController alloc] init];
    concernVC.hidesBottomBarWhenPushed = YES;
//    [concernVC.shopArray addObjectsFromArray:self.productArray];
    concernVC.shopArray = [NSMutableArray arrayWithArray:self.productArray];
    [self.navigationController pushViewController:concernVC animated:YES];
    
}
- (void)clickProductBtn:(UIButton *)btn{
    long int tag = btn.tag - 200;
    NSLog(@"product num%ld",tag);
    NSDictionary *productDic = self.productArray[tag];
    
    ProductDetailController *concernVC = [[ProductDetailController alloc] init];
    concernVC.hidesBottomBarWhenPushed = YES;
    concernVC.dataStr = productDic[@"url"];
    [self.navigationController pushViewController:concernVC animated:YES];
}

#pragma mark --- MainMiddleDelegate
- (void)selectedHero:(NSInteger)index{
    NSLog(@"点击了第%ld个Item",index);
}

#pragma mark - <UIScrollViewDelegate代理方法>
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
//    NSLog(@"y: %f",scrollView.contentOffset.y);
    if (scrollView.contentOffset.y>0) {
        self.naviView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:scrollView.contentOffset.y/64.0];
    }else{
        self.naviView.backgroundColor = [UIColor clearColor];
    }
}
//人为拖拽停止并且减速完全停止时会调用
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
    //在已经减速结束的时候进行图片更新，pagecontrol的更新
    [self updateImageViewsAndPageControl];
}

//在调用setContentOffset方法的时候，会触发此代理方法
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
    
    //在调用setContentOffset方法的时候，会触发此代理方法（避免在定时器控制偏移量的时候不刷新UI）
    [self updateImageViewsAndPageControl];
    
}
- (void)updateImageViewsAndPageControl {
    //先判断出scrollview的操作行为是向左向右还是不动
    //定义一个flag,目前是让scrollview向左向右滑动的时候索引对应的+1或者-1
    int flag = 0;
    if (self.scrollView.contentOffset.x >= ScreenWidth){//手指向左滑动
        flag = 1;
    //原本偏移量是一个宽度,现在==0了,那么就是手指向右滑动了
    } else if (self.scrollView.contentOffset.x == 0){//手指向右滑动
        flag = -1;
    } else  {//除了向左向右之外就是没有移动,那么不需要任何操作，直接返回
        return;
    }
    if (self.scrollView.contentOffset.x == 0) {
        if (flag == 1) {
            self.pageControl.currentPage = 1;
        }else{
            self.pageControl.currentPage = 0;
        }
    }else{
        if (flag == -1) {
            self.pageControl.currentPage = 0;
        }else{
            self.pageControl.currentPage = 1;
        }
    }
}

#pragma mark --- UITableViewDataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        if (self.storyArray.count == 0) {
            return 0;
        }
        return 1;
    }else if (section == 1){
        return 0;
    }
    if (self.storyArray.count == 0) {
        return 0;
    }
    return self.storyArray.count - 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if (indexPath.section == 0) {
        NSDictionary *dataDic = self.storyArray[indexPath.row];
        NSArray *images = [dataDic objectForKey:@"store_images"];
        
        [cell.headImageView sd_setImageWithURL:images[0] placeholderImage:[UIImage imageNamed:@"footerImageView"]];
        cell.nameLabel.text = dataDic[@"name"];
        [cell.distance setTitle:[NSString stringWithFormat:@"1.%02ld",indexPath.row*21] forState:UIControlStateNormal];
        cell.descLabel.text = dataDic[@"address"];
        cell.numLabel.text = [NSString stringWithFormat:@"月销:%d",[dataDic[@"sales_per_month"] intValue]];
        return cell;
    }
    NSDictionary *cellDic = self.storyArray[indexPath.row+1];
    NSArray *images = [cellDic objectForKey:@"store_images"];
    
    [cell.headImageView sd_setImageWithURL:images[0] placeholderImage:[UIImage imageNamed:@"footerImageView"]];
    cell.nameLabel.text = cellDic[@"name"];
    [cell.distance setTitle:[NSString stringWithFormat:@"1.%02ldkm",indexPath.row*3] forState:UIControlStateNormal];
    cell.descLabel.text = cellDic[@"address"];
    cell.numLabel.text = cellDic[@"category"];
    
    
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 475*self.scaleX)];
        headerView.backgroundColor = [UIColor clearColor];
        self.topBannerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 310*self.scaleX)];
        self.topFuncView = [[UIView alloc] init];
        
        [headerView addSubview:self.topBannerView];
        [headerView addSubview:self.topFuncView];
        [self.topFuncView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.mas_equalTo(0);
            make.top.equalTo(self.topBannerView.mas_bottom).with.offset(0);
        }];
        
        if (self.bannerArray.count != 0) {
            [self setupBannerView];
        }
        return headerView;
    } else if (section == 1) {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 325*self.scaleX)];
        headerView.backgroundColor = [UIColor colorWithRed:246/255.0 green:246/255.0 blue:246/255.0 alpha:1.0];
//        UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 315*self.scaleX)];
//        bgView.backgroundColor = [UIColor whiteColor];
        UIView *topView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 45*self.scaleX)];
        topView.backgroundColor = [UIColor whiteColor];
        self.productView = [[UIView alloc] init];
        self.productView.backgroundColor = [UIColor whiteColor];
        
        UILabel *label = [[UILabel alloc] init];
        label.text = @"精品推荐";
        label.font = [UIFont systemFontOfSize:14.0];
        UIButton *moreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        moreBtn.titleLabel.font = [UIFont systemFontOfSize:12.0];
        [moreBtn setTitle:@"更多" forState:UIControlStateNormal];
        [moreBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [moreBtn setImage:[UIImage imageNamed:@"info_rightBoult"] forState:UIControlStateNormal];
        [moreBtn addTarget:self action:@selector(clickMoreBtn) forControlEvents:UIControlEventTouchUpInside];
        
//        [headerView addSubview:bgView];
        [headerView addSubview:topView];
        [headerView addSubview:self.productView];
        [topView addSubview:label];
        [topView addSubview:moreBtn];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(12);
            make.top.bottom.mas_equalTo(0);
        }];
        [moreBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-20);
            make.centerY.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(70*self.scaleX, 30*self.scaleX));
        }];
        [moreBtn setTitleEdgeInsets:UIEdgeInsetsMake(0 ,-moreBtn.imageView.frame.size.width*2 - 10, 0, 0)];//文字距离上边框的距离增加imageView的高度，距离左边框减少imageView的宽度，距离下边框和右边框距离不变
        [moreBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -moreBtn.titleLabel.frame.size.width*2)];//图片距离右边框距离减少图片的宽度，其它不边
        [self.productView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.mas_equalTo(0);
            make.top.equalTo(topView.mas_bottom).with.offset(0.5);
        }];
        
        if (self.productArray.count != 0) {
            [self setupProductView];
        }
        return headerView;
    }
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 50*self.scaleX)];
    UILabel *label = [[UILabel alloc] init];
    label.text = @"附近商铺";
    label.font = [UIFont systemFontOfSize:14.0];
    [headerView addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(12);
        make.top.bottom.mas_equalTo(0);
    }];
    
    return headerView;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (section == 0) {
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 350*self.scaleX)];
//        footerView.backgroundColor = [UIColor brownColor];
        self.middleView = [[MainMiddleCollectionView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 350*self.scaleX)];
        self.middleView.delegate = self;
        self.middleView.dataSource = self.middleArray;
        [footerView addSubview:self.middleView];
        
        return footerView;
    } else if (section == 1) {
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 165*self.scaleX)];
        footerView.backgroundColor = [UIColor colorWithRed:246/255.0 green:246/255.0 blue:246/255.0 alpha:1.0];
        UIView *bgView = [[UIView alloc] init];
        bgView.backgroundColor = [UIColor whiteColor];
        if (self.bottomArray.count == 0) {
            return footerView;
        }
        NSDictionary *dic = self.bottomArray[0];
        UIImageView *bgImageView = [[UIImageView alloc] init];
        [bgImageView sd_setImageWithURL:dic[@"image"] placeholderImage:[UIImage imageNamed:@"footerImageView"]];
        [footerView addSubview:bgView];
        [bgView addSubview:bgImageView];
        
        [bgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(0);
            make.top.mas_equalTo(5);
            make.bottom.mas_equalTo(-5);
        }];
        [bgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(6);
            make.right.bottom.mas_equalTo(-10);
        }];
        
        return footerView;
    }
    return nil;
}

#pragma mark --- UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}
                              
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if(section == 0){
        return 475*self.scaleX;
    }else if (section == 1){
        return 325*self.scaleX;
    }
    return 50*self.scaleX;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if(section == 0){
        return 350*self.scaleX;
    }else if (section == 1){
        return 165*self.scaleX;
    }
    return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 1) {
        return 0;
    }
    return 122*self.scaleX;
}



@end
