//
//  BannerWebViewController.h
//  同行
//
//  Created by Duke on 2017/3/5.
//  Copyright © 2017年 Duke. All rights reserved.
//

#import "BaseViewController.h"

@interface BannerWebViewController : BaseViewController

@property (nonatomic, strong) NSString *picUrl;

@end
