//
//  naviItem.m
//  团购
//
//  Created by Duke on 2016/10/23.
//  Copyright © 2016年 Duke. All rights reserved.
//

#import "naviItem.h"

@interface naviItem()

@end

@implementation naviItem

+ (instancetype)makeSingleItem{

    return [[[NSBundle mainBundle] loadNibNamed:@"naviItem" owner:self options:nil] firstObject];
}

- (void)addTarget:(id)target action:(SEL)action{
    
    [self.itemBtn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
