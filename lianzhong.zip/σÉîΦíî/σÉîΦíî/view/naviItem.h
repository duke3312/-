//
//  naviItem.h
//  团购
//
//  Created by Duke on 2016/10/23.
//  Copyright © 2016年 Duke. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface naviItem : UIView

@property (weak, nonatomic) IBOutlet UIButton *itemBtn;
@property (weak, nonatomic) IBOutlet UIImageView *backImage;
@property (weak, nonatomic) IBOutlet UILabel *itemLabel;

+ (instancetype)makeSingleItem;

- (void)addTarget:(id)target action:(SEL)action;

@end
